#!/usr/bin/env python3
"""Reference update channel server.

Serves ``manifest.json`` and the artifacts next to it, and can *publish* a
signed release built by ``scripts/make_release.py``.

Two modes
---------
``--serve DIR``      serve an already-built release directory (default)
``--watch SRC``      rebuild + sign on demand when ``POST /v1/publish`` is called
                     (needs the signing key in ``$BRAIN_UPDATE_KEY``)

Because the client verifies the manifest signature against a pinned key, this
server can be hosted on an untrusted CDN: compromising it lets an attacker
*deny* updates, not forge them.

    python cloud/update_server/app.py --serve /var/www/brain-releases --port 8791
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlparse

SAFE = re.compile(r"^[A-Za-z0-9._\-/]+$")


class Handler(BaseHTTPRequestHandler):
    server_version = "brain-updates/1.0"
    protocol_version = "HTTP/1.1"
    root: Path = None
    tokens: set = set()

    def log_message(self, fmt, *args) -> None:
        pass

    def _send(self, status: int, payload=None, raw: bytes | None = None,
              ctype: str = "application/json") -> None:
        data = raw if raw is not None else json.dumps(payload or {}).encode()
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-cache" if ctype == "application/json" else "public, max-age=300")
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self) -> None:   # noqa: N802
        parsed = urlparse(self.path)
        if parsed.path in ("/health", "/v1/health"):
            return self._send(200, {"ok": True, "service": "brain-updates",
                                    "root": str(self.root)})
        rel = parsed.path.lstrip("/")
        if rel.startswith("v1/"):
            rel = rel[3:]
        if not rel or not SAFE.match(rel) or ".." in rel:
            return self._send(400, {"error": "bad path"})
        candidate = (self.root / unquote(rel)).resolve()
        if not str(candidate).startswith(str(self.root.resolve())):
            return self._send(403, {"error": "path traversal refused"})
        if not candidate.is_file():
            return self._send(404, {"error": "not found"})
        if candidate.name in ("manifest.json",) or candidate.suffix == ".json":
            return self._send(200, None, raw=candidate.read_bytes())
        return self._send(200, None, raw=candidate.read_bytes(),
                          ctype="application/octet-stream")

    def do_POST(self) -> None:  # noqa: N802
        parsed = urlparse(self.path)
        if parsed.path not in ("/v1/publish", "/publish"):
            return self._send(404, {"error": "not found"})
        header = self.headers.get("Authorization", "")
        if self.tokens and header[7:].strip() not in self.tokens:
            return self._send(401, {"error": "invalid token"})
        length = int(self.headers.get("Content-Length") or 0)
        try:
            body = json.loads(self.rfile.read(length) or b"{}")
        except json.JSONDecodeError:
            return self._send(400, {"error": "body must be JSON"})
        src = Path(str(body.get("release_dir", ""))).expanduser()
        if not src.is_dir():
            return self._send(400, {"error": f"release_dir not found: {src}"})
        copied = []
        for item in src.rglob("*"):
            if item.is_file() and item.name != "keys.json":
                dest = self.root / item.relative_to(src)
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_bytes(item.read_bytes())
                copied.append(str(item.relative_to(src)))
        return self._send(200, {"ok": True, "published": copied,
                                "manifest": f"{self.root}/manifest.json"})


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--serve", required=True, help="directory holding manifest.json + artifacts")
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8791)
    ap.add_argument("--token-env", default="BRAIN_UPDATE_TOKEN",
                    help="env var with the publish token (GET is public)")
    args = ap.parse_args()

    root = Path(args.serve).expanduser().resolve()
    if not (root / "manifest.json").exists():
        print(f"warning: {root}/manifest.json does not exist yet "
              f"(run scripts/make_release.py --out {root})", file=sys.stderr)
    Handler.root = root
    Handler.tokens = {t for t in os.environ.get(args.token_env, "").split(",") if t.strip()}

    httpd = ThreadingHTTPServer((args.host, args.port), Handler)
    print(f"brain-updates listening on http://{args.host}:{args.port} root={root}", flush=True)
    print(f"  client: brain update-channel-add stable "
          f"http://{args.host}:{args.port}/v1/manifest.json --mode strict --public <b64>")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nstopping")
    finally:
        httpd.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
