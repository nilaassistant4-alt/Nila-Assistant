# Changelog

## 0.1.0 (first Windows build of the new core)

### Security (Phase 0)
- Passphrase alone no longer opens the vault. An authenticator code is required; a vault with no
  second factor refuses everything except `brain totp` / `brain enroll-voice`.
- `brain totp` confirms your 6-digit code before saving the secret (a typo cannot lock you out).
- Recovery codes work as a one-time break-glass login (`--recovery`).
- Access token compared in constant time and no longer printed (browser receives it privately).
- Standing grants last 24 hours (was 7 days); network access can no longer be a standing grant.
- `run_command`: rejects chaining/redirection, runs in a private workspace folder, secret-looking
  environment variables removed.
- Taint rule: after untrusted content (file, photo, network, command output) enters a reply,
  high-risk tools are held for the rest of that reply.
- Provider addresses validated: the Gemini key is only sent to Google (or loopback); local AI must
  be on this PC.

### Features (Phase 1)
- Chat panel in the dashboard with a label showing where each answer ran.
- Router with three lanes (this PC / online / built-in engine); online only on request, only
  for non-private messages, only within budget.
- Usage ledger with daily cap, per-minute cap, stop-at-percent, 429 cool-down, failures counted.
- Gemini provider. 
- Projects: ideas, 9-block business model, milestones, notes, status, next steps, resume,
  encrypted file attachments. Works offline.
- Capability map (possible / asks first / needs setup / blocked / planned) and health report.
- Windows scripts: `setup.bat`, `start-nila.bat`, `report.bat`, `nila-cmd.bat`.

### Tests
- 42 new tests (`tests/test_v01.py`). Existing suite kept green; one test updated because network
  access is intentionally no longer a standing grant.
