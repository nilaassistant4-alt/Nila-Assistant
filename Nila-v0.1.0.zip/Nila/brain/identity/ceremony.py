"""The unlock/enrol ceremony: passphrase (KDF) + voice (biometric) + liveness.

Policy matrix
-------------
mode ``full``      passphrase + spoken random challenge + liveness  -> trusted session
mode ``voice``     voice + liveness, passphrase cached in keyring   -> trusted session
mode ``totp``      passphrase + TOTP code                           -> trusted, ``degraded``
mode ``recovery``  recovery code (break-glass)                      -> trusted, ``degraded``,
                                                                    forces re-enrolment flag
mode ``passphrase``passphrase only                                  -> **refused** unless
                                                                    policy.allow_degraded

Every attempt - pass or fail - is written to the hash-chained audit journal,
and failures drive exponential lockout (see ``Vault.register_failure``).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from ..config import Config
from ..crypto.hash import fast_kdf
from ..memory.vault import Session, Vault
from ..util.misc import now_ms
from .liveness import LivenessGuard
from .totp import generate_recovery_codes, generate_secret, provisioning_uri, verify as totp_verify
from .voice import VoiceVerifier


class CeremonyError(RuntimeError):
    def __init__(self, message: str, reasons: Optional[List[str]] = None):
        super().__init__(message)
        self.reasons = reasons or []


@dataclass
class CeremonyResult:
    ok: bool
    mode: str
    session: Optional[Session] = None
    detail: Dict[str, Any] = field(default_factory=dict)
    reasons: List[str] = field(default_factory=list)


class IdentityCeremony:
    def __init__(self, config: Config, vault: Vault):
        self.config = config
        self.vault = vault
        vcfg = config.voice_config()
        self.voice = VoiceVerifier(vault, threshold=vcfg["threshold"], backend_name=vcfg["backend"])
        self.liveness = LivenessGuard(
            key=fast_kdf((vault.data.get("kdf", {}).get("salt", "x")).encode(),
                         b"pbx/liveness/v1", 32),
            ttl_seconds=90,
            replay_window=vcfg["replay_window"],
            challenge_len=vcfg["challenge_len"],
            min_duration=vcfg["min_duration"],
            max_duration=vcfg["max_duration"],
        )

    # ------------------------------------------------------------------ #
    # enrolment
    # ------------------------------------------------------------------ #
    def enroll_voice(self, samples: List[Any]) -> Dict[str, Any]:
        if not self.vault.is_unlocked():
            raise CeremonyError("unlock the vault before enrolling a voice")
        if len(samples) < int(self.config.voice_config()["samples"]):
            raise CeremonyError(
                f"need {self.config.voice_config()['samples']} enrolment samples, got {len(samples)}")
        report = self.voice.enroll(samples)
        if report.get("intra_speaker_min") is not None and report["intra_speaker_min"] < 0.35:
            report["warning"] = ("enrolment samples disagree strongly - re-record in a quieter "
                                 "room with the same microphone")
        return report

    def enroll_totp(self, account: Optional[str] = None) -> Dict[str, Any]:
        if not self.vault.is_unlocked():
            raise CeremonyError("unlock the vault first")
        secret = generate_secret()
        self.vault.store_totp(secret)
        acct = account or self.vault.user
        self.vault.audit("totp_enrolled", {"account": acct})
        return {"secret": secret, "uri": provisioning_uri(secret, acct)}

    def enroll_recovery_codes(self, n: int = 8) -> List[str]:
        if not self.vault.is_unlocked():
            raise CeremonyError("unlock the vault first")
        codes = generate_recovery_codes(n)
        self.vault.store_recovery_codes(codes)
        self.vault.audit("recovery_codes_issued", {"count": n})
        return codes

    # ------------------------------------------------------------------ #
    # challenge / verify
    # ------------------------------------------------------------------ #
    def issue_challenge(self, style: str = "digits") -> Dict[str, Any]:
        if not self.vault.has_voice():
            raise CeremonyError("no voice template enrolled (run: brain enroll-voice)")
        ch = self.liveness.issue(style=style)
        self.vault.audit("challenge_issued", {"nonce": ch.nonce[:8], "style": style})
        return ch.to_dict()

    def verify_voice(self, nonce: str, audio: Any, bound: Optional[str] = None) -> Dict[str, Any]:
        """Step 2 of the ceremony. Returns scores; does NOT start a session."""
        submission = {"nonce": nonce, "audio": audio, "bound": bound}
        live = self.liveness.check(submission)
        if not live.ok:
            self.vault.audit("liveness_failed", {"nonce": nonce[:8], "reasons": live.reasons})
            raise CeremonyError("liveness check failed", live.reasons)
        score = self.voice.verify(audio)
        self.vault.audit("voice_verified", {"nonce": nonce[:8], "score": score.score,
                                            "passed": score.passed, "threshold": score.threshold,
                                            "detail": live.detail})
        if not score.passed:
            wait = self.vault.register_failure("voice-score-below-threshold")
            raise CeremonyError(
                f"voice score {score.score} below threshold {score.threshold}"
                + (f" (locked out {wait}s)" if wait else ""),
                [f"score={score.score}", f"threshold={score.threshold}"],
            )
        return {"score": score.score, "threshold": score.threshold,
                "liveness": live.detail, "backend": score.backend}

    # ------------------------------------------------------------------ #
    # unlock
    # ------------------------------------------------------------------ #
    def unlock(self, passphrase: str, mode: str = "auto", voice_submission: Optional[Dict[str, Any]] = None,
               totp_code: Optional[str] = None, recovery_code: Optional[str] = None) -> CeremonyResult:
        """Run the full ceremony and, on success, start a session.

        ``voice_submission`` = ``{"nonce": ..., "audio": <path|bytes|data-uri>, "bound": ...}``.
        """
        locked, wait = self.vault.locked_out()
        if locked:
            return CeremonyResult(False, mode, reasons=[f"locked out; retry in {wait}s"])

        policy = self.vault.policy()
        vcfg = self.config.voice_config()
        reasons: List[str] = []
        detail: Dict[str, Any] = {}

        # 1. knowledge factor ------------------------------------------------
        try:
            mk = self.vault.unlock(passphrase)
        except PermissionError as exc:
            w = self.vault.register_failure("bad-passphrase")
            return CeremonyResult(False, mode, reasons=[str(exc)] + ([f"locked out {w}s"] if w else []))
        except RuntimeError as exc:
            return CeremonyResult(False, mode, reasons=[str(exc)])
        detail["passphrase"] = "ok"
        # the voice template / TOTP secret are encrypted *with* MK, so hold it in
        # memory provisionally until the second factor is decided.
        self.vault.begin_provisional(mk)

        # 2. choose the second factor ---------------------------------------
        chosen = mode
        has_voice = self.vault.has_voice()
        if chosen == "auto":
            if has_voice and voice_submission and vcfg["require_liveness"]:
                chosen = "voice"
            elif self.vault.load_totp_secret() and totp_code:
                chosen = "totp"
            elif recovery_code:
                chosen = "recovery"
            elif has_voice and voice_submission:
                chosen = "voice"
            else:
                chosen = "passphrase"

        if chosen == "voice":
            if not voice_submission:
                self.vault.discard_provisional()
                return CeremonyResult(False, chosen, reasons=["voice submission required"])
            try:
                detail["voice"] = self.verify_voice(voice_submission["nonce"],
                                                    voice_submission["audio"],
                                                    voice_submission.get("bound"))
            except CeremonyError as exc:
                self.vault.discard_provisional()
                return CeremonyResult(False, chosen, reasons=exc.reasons or [str(exc)], detail=detail)

        elif chosen == "totp":
            secret = self.vault.load_totp_secret()
            if not secret or not totp_code:
                self.vault.discard_provisional()
                return CeremonyResult(False, chosen, reasons=["totp not enrolled or code missing"])
            if not totp_verify(secret, totp_code):
                w = self.vault.register_failure("bad-totp")
                self.vault.discard_provisional()
                return CeremonyResult(False, chosen,
                                      reasons=["invalid TOTP code"] + ([f"locked out {w}s"] if w else []),
                                      detail=detail)
            detail["totp"] = "ok"

        elif chosen == "recovery":
            if not recovery_code or not self.vault.consume_recovery_code(recovery_code):
                w = self.vault.register_failure("bad-recovery-code")
                self.vault.discard_provisional()
                return CeremonyResult(False, chosen,
                                      reasons=["invalid recovery code"] + ([f"locked out {w}s"] if w else []),
                                      detail=detail)
            detail["recovery"] = "consumed"
            self.vault.meta_set("re_enrollment_required", True)

        elif chosen == "passphrase":
            # FAIL CLOSED. A passphrase alone is never a full session: if any
            # second factor exists it must be used, and if none exists the owner
            # must enrol one (``brain totp``) before the vault opens. The only
            # override is the explicit, audited ``identity.allow_degraded``.
            has_totp = bool(self.vault.load_totp_secret())
            needs_factor = (policy.get("require_second_factor", True)
                            or (policy.get("require_voice", True) and has_voice))
            if needs_factor and not policy.get("allow_degraded"):
                self.vault.discard_provisional()
                if has_voice or has_totp:
                    why = ("second factor required: supply a voice challenge "
                           "(brain unlock --voice <wav>) or --totp <code>")
                else:
                    why = ("no second factor is enrolled, so the passphrase alone "
                           "is refused. Run `brain totp` once to enrol an "
                           "authenticator app")
                return CeremonyResult(
                    False, chosen,
                    reasons=[why, "policy.require_second_factor is on (a safety setting)"],
                    detail=detail)
            detail["degraded"] = "passphrase-only session"

        # 3. success ---------------------------------------------------------
        self.vault.register_success()
        degraded = chosen in ("totp", "recovery", "passphrase")
        sess = self.vault.start_session(mk, mode=chosen, degraded=degraded)
        self.vault.audit("session_unlock", {"mode": chosen, "degraded": degraded,
                                            "session": sess.session_id})
        detail["session"] = {"id": sess.session_id, "expires_at": sess.expires_at,
                             "degraded": degraded, "mode": chosen}
        return CeremonyResult(True, chosen, session=sess, detail=detail)

    # ------------------------------------------------------------------ #
    def step_up(self, passphrase: str, voice_submission: Optional[Dict[str, Any]] = None) -> CeremonyResult:
        """Re-authenticate for high-risk ops (export, rotate key, delete all)."""
        return self.unlock(passphrase, mode="voice" if voice_submission else "auto",
                           voice_submission=voice_submission)

    def lock(self) -> None:
        self.vault.lock(reason="manual")
