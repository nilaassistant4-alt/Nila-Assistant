"""Usage ledger: counts cloud requests per provider per day and enforces limits.

Why this exists: free API tiers have small daily and per-minute limits, and some
providers count FAILED calls against them. The ledger counts every attempt
(success or failure), stops BEFORE the limit is reached, honours rate-limit
cool-downs, and never stores any message text - only counters.

FAIL CLOSED: if the owner has not set a limit, a conservative default applies
instead of "unlimited".
"""
from __future__ import annotations

import datetime as _dt
import json
import os
import threading
import time
from collections import deque
from pathlib import Path
from typing import Any, Callable, Deque, Dict, Tuple

DEFAULT_DAILY_CAP = 20      # used only when the owner has not set daily_requests
DEFAULT_RPM = 5
DEFAULT_STOP_PCT = 80
KEEP_DAYS = 14


class UsageLedger:
    def __init__(self, path: Path | str, clock: Callable[[], float] = time.time):
        self.path = Path(path)
        self.clock = clock
        self._lock = threading.RLock()
        self._recent: Dict[str, Deque[float]] = {}

    # ------------------------------------------------------------------ #
    def _today(self) -> str:
        return _dt.datetime.fromtimestamp(self.clock()).strftime("%Y-%m-%d")

    def _load(self) -> Dict[str, Any]:
        try:
            data = json.loads(self.path.read_text("utf-8"))
            if isinstance(data, dict):
                data.setdefault("days", {})
                data.setdefault("cooldown", {})
                return data
        except (OSError, ValueError):
            pass
        return {"days": {}, "cooldown": {}}

    def _save(self, data: Dict[str, Any]) -> None:
        days = sorted(data["days"])
        for d in days[:-KEEP_DAYS]:
            data["days"].pop(d, None)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, indent=1), "utf-8")
        os.replace(tmp, self.path)

    # ------------------------------------------------------------------ #
    @staticmethod
    def limits(cfg: Dict[str, Any]) -> Dict[str, Any]:
        cap = int(cfg.get("daily_requests") or 0)
        return {
            "cap": cap if cap > 0 else DEFAULT_DAILY_CAP,
            "cap_is_default": cap <= 0,
            "rpm": int(cfg.get("rpm") or DEFAULT_RPM),
            "stop_pct": min(100, max(10, int(cfg.get("stop_at_pct") or DEFAULT_STOP_PCT))),
        }

    def usage(self, provider: str) -> Dict[str, int]:
        with self._lock:
            day = self._load()["days"].get(self._today(), {})
            u = day.get(provider, {})
            return {"requests": int(u.get("requests", 0)), "failures": int(u.get("failures", 0)),
                    "tokens": int(u.get("tokens", 0))}

    def cooldown_left(self, provider: str) -> int:
        with self._lock:
            until = float(self._load()["cooldown"].get(provider, 0))
            return max(0, int(until - self.clock()))

    def check(self, provider: str, cfg: Dict[str, Any]) -> Tuple[bool, str]:
        lim = self.limits(cfg)
        left = self.cooldown_left(provider)
        if left > 0:
            return False, (f"{provider} asked us to slow down; paused for another {left}s")
        used = self.usage(provider)["requests"]
        allowed = max(1, lim["cap"] * lim["stop_pct"] // 100)
        if used >= allowed:
            return False, (f"daily limit reached for {provider} ({used} of {allowed} allowed, "
                           f"cap {lim['cap']}); it resets tomorrow")
        with self._lock:
            q = self._recent.setdefault(provider, deque())
            now = self.clock()
            while q and now - q[0] > 60:
                q.popleft()
            if len(q) >= lim["rpm"]:
                return False, f"too many {provider} requests this minute (limit {lim['rpm']})"
        return True, ""

    def record(self, provider: str, ok: bool, tokens: int = 0) -> None:
        with self._lock:
            data = self._load()
            day = data["days"].setdefault(self._today(), {})
            u = day.setdefault(provider, {"requests": 0, "failures": 0, "tokens": 0})
            u["requests"] += 1          # failed calls count: some providers charge them too
            if not ok:
                u["failures"] += 1
            u["tokens"] += max(0, int(tokens or 0))
            self._save(data)
            self._recent.setdefault(provider, deque()).append(self.clock())

    def set_cooldown(self, provider: str, seconds: int) -> None:
        with self._lock:
            data = self._load()
            data["cooldown"][provider] = self.clock() + max(1, min(int(seconds), 3600))
            self._save(data)

    def snapshot(self, provider: str, cfg: Dict[str, Any]) -> Dict[str, Any]:
        lim = self.limits(cfg)
        u = self.usage(provider)
        allowed = max(1, lim["cap"] * lim["stop_pct"] // 100)
        return {"provider": provider, "used": u["requests"], "failures": u["failures"],
                "tokens": u["tokens"], "cap": lim["cap"], "allowed": allowed,
                "remaining": max(0, allowed - u["requests"]),
                "pct": min(100, round(100 * u["requests"] / allowed)),
                "cap_is_default": lim["cap_is_default"],
                "cooldown_s": self.cooldown_left(provider)}
