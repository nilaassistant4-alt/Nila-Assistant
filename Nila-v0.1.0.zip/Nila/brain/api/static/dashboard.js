"use strict";
// The access token arrives in the URL fragment (never sent to the server, never logged).
const TOKEN = location.hash.slice(1);
history.replaceState(null, "", location.pathname);
const $ = id => document.getElementById(id);
const el = (tag, text, cls) => { const e = document.createElement(tag); if (text != null) e.textContent = text; if (cls) e.className = cls; return e; };
const api = (p, body) => fetch(p, { method: body ? "POST" : "GET", headers: { "Authorization": "Bearer " + TOKEN, "Content-Type": "application/json" }, body: body ? JSON.stringify(body) : undefined })
  .then(async r => { const j = await r.json().catch(() => ({})); if (!r.ok) throw new Error(j.error || r.status); return j; });
const CANVAS = [["problem", "Problem"], ["customers", "Customers"], ["value_prop", "Value proposition"], ["solution", "Solution"], ["channels", "Channels"], ["revenue", "Revenue"], ["costs", "Costs"], ["metrics", "Key metric"], ["advantage", "Advantage"]];
const STATUSES = ["idea", "validating", "planning", "building", "launched", "paused", "done"];
let load = 0.2, filesOk = false, CUR = null;

// ---------------------------------------------------------------- chat
function bubble(text, me) { const b = el("div", text, "bub" + (me ? " me" : "")); $("msgs").append(b); $("msgs").scrollTop = 1e9; return b; }
function routeBadge(route) {
  const w = route && route.where ? route.where : "local";
  const cls = route && route.blocked ? "blocked" : (w === "online" ? "online" : "local");
  const label = (w === "online" ? "went online: " : (w === "offline" ? "stayed on this PC: " : "stayed on this PC: ")) + ((route && route.label) || "");
  return el("div", label, "badge " + cls);
}
async function send() {
  const t = $("msg").value.trim(); if (!t) return;
  const mode = document.querySelector("input[name=mode]:checked").value;
  bubble(t, true); $("msg").value = ""; $("send").disabled = true;
  const wait = bubble("thinking…");
  try {
    const r = await api("/v1/chat", { message: t, mode });
    wait.textContent = r.answer || (r.error ? "Problem: " + r.error : "(no reply)");
    if (r.route) { wait.append(routeBadge(r.route)); if (r.route.notice) wait.append(el("div", r.route.notice, "notice")); }
    if (r.error && r.answer) wait.append(el("div", r.error, "notice"));
  } catch (e) { wait.textContent = "Could not reach Nila: " + e.message; }
  $("send").disabled = false; $("msg").focus();
  loadProjects(); tick(); slow();
}
$("send").onclick = send;
$("msg").addEventListener("keydown", e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } });
bubble("Hi, I’m Nila. Save an idea, ask me to resume a project, or just talk. Under every answer I show whether it stayed on this PC or went online. Check “What Nila can do” on the right to see what is ready, what needs your permission, and what isn’t built yet.");

// ---------------------------------------------------------------- projects
async function loadProjects() {
  try {
    const d = await api("/v1/projects"), box = $("plist"); box.replaceChildren();
    if (!d.projects.length) box.append(el("div", "No projects yet. Add an idea below.", "mu"));
    d.projects.forEach(p => {
      const x = el("div", null, "proj" + (p.id === CUR ? " on" : ""));
      x.append(el("div", p.title), el("small", p.status + " · " + p.updated_ago + " · business model " + p.canvas_filled + "/" + p.canvas_total));
      x.onclick = () => showProject(p.id); box.append(x);
    });
    const r = await api("/v1/projects/resume"), rs = $("resume");
    rs.textContent = r.resume ? "Pick up where you left off: " + r.resume.project.title + " (" + r.resume.project.status + ")" : "";
    rs.style.cursor = r.resume ? "pointer" : "default";
    rs.onclick = r.resume ? () => showProject(r.resume.project.id) : null;
  } catch (e) { $("plist").textContent = "projects unavailable: " + e.message; }
}
$("padd").onclick = async () => {
  const t = $("ptitle").value.trim(); if (!t) return;
  try { const r = await api("/v1/projects", { title: t, idea: "" }); $("ptitle").value = ""; CUR = r.project.id; await loadProjects(); showProject(CUR); }
  catch (e) { alert(e.message); }
};
function b64(buf) { let s = ""; const u = new Uint8Array(buf); for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000)); return btoa(s); }
async function post(id, action, body) { await api("/v1/projects/" + encodeURIComponent(id) + "/" + action, body); await showProject(id); loadProjects(); }
async function showProject(id) {
  CUR = id; const box = $("pdetail"); box.replaceChildren();
  let d;
  try { d = await api("/v1/projects/" + encodeURIComponent(id)); } catch (e) { box.textContent = e.message; return; }
  const p = d.project, r = d.report, w = el("div", null, "box");
  w.append(el("b", p.title));
  const sr = el("div", null, "row m"), ss = document.createElement("select");
  STATUSES.forEach(s => { const o = el("option", s); o.value = s; if (s === p.status) o.selected = true; ss.append(o); });
  const sb = el("button", "Set status"); sb.onclick = () => post(id, "status", { status: ss.value }).catch(e => alert(e.message)); sr.append(ss, sb); w.append(sr);
  w.append(el("pre", r.summary), el("b", "Next steps"));
  const ul = el("ul"); r.next_steps.forEach(s => ul.append(el("li", s))); w.append(ul);
  w.append(el("b", "Business model"));
  CANVAS.forEach(([k, label]) => { w.append(el("div", label + ": " + (p.canvas[k] || "—"), p.canvas[k] ? "m" : "m mu")); });
  const cr = el("div", null, "row m"), cs = document.createElement("select"), ci = document.createElement("input");
  CANVAS.forEach(([k, label]) => { const o = el("option", label); o.value = k; cs.append(o); }); ci.placeholder = "fill in this block…";
  const cb = el("button", "Save"); cb.onclick = () => ci.value.trim() && post(id, "canvas", { block: cs.value, text: ci.value }).catch(e => alert(e.message)); cr.append(cs, ci, cb); w.append(cr);
  w.append(el("b", "Milestones"));
  p.milestones.forEach((m, i) => {
    const row = el("div", (m.done ? "✔ " : "○ ") + m.text, "m");
    if (!m.done) { const b = el("button", "Done"); b.onclick = () => post(id, "complete", { index: i + 1 }).catch(e => alert(e.message)); row.append(b); }
    w.append(row);
  });
  const mr = el("div", null, "row m"), mi = document.createElement("input"), mb = el("button", "Add"); mi.placeholder = "next milestone…";
  mb.onclick = () => mi.value.trim() && post(id, "milestone", { text: mi.value }).catch(e => alert(e.message)); mr.append(mi, mb); w.append(mr);
  w.append(el("b", "Notes"));
  p.notes.slice(-5).forEach(n => w.append(el("div", new Date(n.ts).toLocaleDateString() + ": " + n.text, "m mu")));
  const nr = el("div", null, "row m"), ni = document.createElement("input"), nb = el("button", "Add"); ni.placeholder = "progress note…";
  nb.onclick = () => ni.value.trim() && post(id, "note", { text: ni.value }).catch(e => alert(e.message)); nr.append(ni, nb); w.append(nr);
  w.append(el("b", "Files (encrypted)"));
  p.files.forEach(f => {
    const row = el("div", f.name + " · " + Math.round(f.size / 1024) + " KB", "m"), b = el("button", "Save copy");
    b.onclick = async () => {
      try {
        const g = await api("/v1/projects/" + encodeURIComponent(id) + "/files/" + encodeURIComponent(f.id));
        const bin = atob(g.data_b64), u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
        const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([u])); a.download = g.name; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 4000);
      } catch (e) { alert(e.message); }
    };
    row.append(b); w.append(row);
  });
  const fi = document.createElement("input"); fi.type = "file";
  fi.onchange = () => {
    const f = fi.files[0]; if (!f) return;
    if (f.size > 8 * 1024 * 1024) { alert("Files can be up to 8 MB."); return; }
    const rd = new FileReader();
    rd.onload = () => post(id, "files", { name: f.name, data_b64: b64(rd.result) }).catch(e => alert(e.message));
    rd.readAsArrayBuffer(f);
  };
  w.append(fi); box.append(w); loadProjects();
}

// ---------------------------------------------------------------- files (read-only browser)
async function ls(p) {
  try {
    const d = await api("/v1/files?path=" + encodeURIComponent(p || ""));
    filesOk = true; $("path").textContent = d.path || "allowed folders";
    const box = $("files"); box.replaceChildren();
    if (d.parent != null && d.path) { const u = el("div", "\u2b11 .."); u.onclick = () => ls(d.parent); box.append(u); }
    d.entries.forEach(e => { const x = el("div", (e.dir ? "\u25b8 " : "\u00b7 ") + e.name); if (e.dir) x.onclick = () => ls(e.path); box.append(x); });
    if (!(d.roots || []).length) box.append(el("div", "No folders are shared with the dashboard. Add one with: brain config set agent.dashboard_roots \"[\\\"C:/Users/you/Documents\\\"]\"", "note"));
    const miss = (d.roots || []).filter(r => !r.exists).map(r => r.configured);
    if (miss.length) box.append(el("div", "\u26a0 folder not found: " + miss.join(", "), "bad"));
  } catch (e) { filesOk = false; $("path").textContent = "unavailable: " + e.message; }
}

// ---------------------------------------------------------------- system, approvals, audit
function bar(label, v) {
  if (v == null) return null;
  const d = el("div", label + " " + v + "%", "m"), p = document.createElement("progress");
  p.max = 100; p.value = v; d.append(p); return d;
}
async function tick() {
  try {
    const [s, mt] = await Promise.all([api("/v1/status"), api("/v1/metrics")]), m = mt.metrics;
    const cpu = m.cpu_pct != null ? m.cpu_pct : (m.load1 != null ? Math.round(m.load1 / (m.cpus || 1) * 100) : null);
    if (cpu != null) load = Math.min(1, cpu / 100);
    if (!filesOk && s.unlocked && s.session && !s.session.degraded) ls("");
    const st = $("st"); st.replaceChildren();
    st.append(el("div", s.unlocked ? "Vault: unlocked" : "Vault: locked - restart Nila to unlock.", s.unlocked ? "m okc" : "m bad"));
    if (s.session) {
      const t = s.session.expires_in_s;
      st.append(el("div", "Session: " + s.session.mode + (s.session.degraded ? " (limited)" : " (full)") + " · expires in " + Math.floor(t / 60) + ":" + String(t % 60).padStart(2, "0"), "m"));
    }
    [bar(m.cpu_pct != null ? "CPU" : "Load avg", cpu), bar("Memory", m.mem_pct), bar("Disk", m.disk_pct), bar("Battery" + (m.plugged ? " \u26a1" : ""), m.battery_pct)].forEach(x => x && st.append(x));
    const a = await api("/v1/audit?limit=10"), log = $("log"); log.replaceChildren();
    a.entries.slice().reverse().forEach(e => log.append(el("div", (e.ts ? new Date(e.ts).toLocaleTimeString() + " " : "") + (e.event || "event"))));
    if (s.unlocked) {
      const c = await api("/v1/consent"), cs = $("cs"); cs.replaceChildren();
      if (!c.pending.length) cs.textContent = "none";
      c.pending.forEach(p => {
        const d = el("div", p.label + " · " + p.scope + (p.purpose ? " — " + p.purpose : ""), "m");
        [["Allow once", "affirm"], ["Deny", "deny"]].forEach(([t, k]) => {
          const b = el("button", t); b.onclick = () => api("/v1/consent/" + k, { id: p.id }).then(tick).catch(e => alert(e.message)); d.append(b);
        });
        cs.append(d);
      });
    }
  } catch (e) {
    const expired = /401|expired|unauthor/i.test(e.message);
    $("st").replaceChildren(el("span", expired ? "session expired - restart Nila (start-nila.bat) to unlock again." : "disconnected: " + e.message, "bad"));
  }
}
const STATE_TEXT = { possible: "ready", needs_permission: "asks you first", needs_setup: "needs setup", blocked: "blocked", planned: "not built yet" };
async function slow() {
  try {
    const b = await api("/v1/budget"), bx = $("bud"); bx.replaceChildren();
    if (!b.budgets.length) bx.textContent = "not used";
    b.budgets.forEach(x => {
      const d = el("div", x.provider + ": " + x.used + " of " + x.allowed + " requests today" + (x.cooldown_s ? " · paused " + x.cooldown_s + "s" : ""), "m"), p = document.createElement("progress");
      p.max = 100; p.value = x.pct; d.append(p); bx.append(d);
      if (x.cap_is_default) bx.append(el("div", "Using a safe default limit. Set your real one from your Google AI Studio page.", "note"));
    });
    const c = await api("/v1/capabilities"), cx = $("caps"); cx.replaceChildren();
    c.capabilities.forEach(i => {
      const row = el("div", null, "cap"); row.title = [i.reason, i.how].filter(Boolean).join(" — ");
      row.append(el("span", i.label), el("span", STATE_TEXT[i.state] || i.state, "st-" + i.state)); cx.append(row);
    });
    const h = await api("/v1/diagnostics"), hx = $("hl"); hx.replaceChildren();
    h.health.forEach(i => {
      const row = el("div", i.name + ": " + i.detail, "m " + (i.status === "ok" ? "okc" : i.status === "warn" ? "warnc" : "bad")); if (i.fix) row.title = i.fix; hx.append(row);
    });
  } catch (e) { /* the fast poll already shows a disconnected message */ }
}
$("rep").onclick = async () => {
  const bx = $("repbox");
  if (!bx.hidden) { bx.hidden = true; return; }
  try { const r = await api("/v1/diagnostics?format=text"); bx.textContent = r.text; bx.hidden = false; } catch (e) { alert(e.message); }
};

// ---------------------------------------------------------------- background
const cv = $("c"), g = cv.getContext("2d"); let N = [];
function fit() { cv.width = cv.clientWidth; cv.height = cv.clientHeight; N = Array.from({ length: 70 }, () => ({ x: Math.random() * cv.width, y: Math.random() * cv.height, a: Math.random() * 6.28, p: Math.random() * 6.28 })); }
addEventListener("resize", fit); fit();
(function f(t) {
  g.clearRect(0, 0, cv.width, cv.height); const sp = .3 + load * 2.2;
  N.forEach(n => { n.a += (Math.random() - .5) * .2; n.x = (n.x + Math.cos(n.a) * sp + cv.width) % cv.width; n.y = (n.y + Math.sin(n.a) * sp + cv.height) % cv.height; });
  for (let i = 0; i < N.length; i++) for (let j = i + 1; j < N.length; j++) { const d = Math.hypot(N[i].x - N[j].x, N[i].y - N[j].y); if (d < 110) { g.strokeStyle = "rgba(90,209,255," + ((1 - d / 110) * .45) + ")"; g.beginPath(); g.moveTo(N[i].x, N[i].y); g.lineTo(N[j].x, N[j].y); g.stroke(); } }
  N.forEach(n => { g.fillStyle = "rgba(140,230,255," + (.55 + .45 * Math.sin(t / 400 + n.p)) + ")"; g.beginPath(); g.arc(n.x, n.y, 2.4, 0, 6.28); g.fill(); });
  requestAnimationFrame(f);
})(0);
ls(""); tick(); loadProjects(); slow(); setInterval(tick, 2000); setInterval(slow, 15000);
