"""``brain`` command line interface.

Text-first interaction (a stated requirement) with a REPL, plus explicit
sub-commands for every lifecycle operation: init, enrol, unlock, memory,
sync, updates, devices, diagnostics.

Nothing sensitive is ever taken as a command-line argument where it can be
avoided - passphrases come from a hidden prompt, ``--passphrase-env VAR``, or
stdin, because argv is world-readable via /proc on multi-user systems.
"""
from __future__ import annotations

import argparse
import getpass
import json
import os
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

from ..config import Config
from ..memory.store import MemoryStore
from ..memory.vault import Vault
from ..util.misc import dumps


# --------------------------------------------------------------------------- #
# helpers
# --------------------------------------------------------------------------- #
class UI:
    def __init__(self, quiet: bool = False, json_out: bool = False):
        self.quiet = quiet
        self.json = json_out

    def say(self, msg: str = "") -> None:
        if not self.quiet and not self.json:
            print(msg)

    def warn(self, msg: str) -> None:
        if not self.json:
            print(f"\033[33m! {msg}\033[0m", file=sys.stderr)

    def err(self, msg: str) -> int:
        if self.json:
            print(json.dumps({"ok": False, "error": msg}))
        else:
            print(f"\033[31merror:\033[0m {msg}", file=sys.stderr)
        return 1

    def ok(self, msg: str) -> None:
        self.say(f"\033[32m{msg}\033[0m")

    def emit(self, payload: Dict[str, Any]) -> None:
        if self.json:
            print(json.dumps(payload, indent=2, default=str))
        else:
            for k, v in payload.items():
                if isinstance(v, (dict, list)):
                    v = dumps(v)
                print(f"  {k:<22s} {v}")


def read_passphrase(args, prompt: str = "master passphrase: ", confirm: bool = False) -> str:
    env = getattr(args, "passphrase_env", None)
    if env:
        val = os.environ.get(env, "")
        if not val:
            raise SystemExit(f"environment variable {env} is empty/unset")
        return val
    if getattr(args, "passphrase_stdin", False):
        return sys.stdin.readline().rstrip("\n")
    if getattr(args, "passphrase", None):
        return args.passphrase
    if not sys.stdin.isatty():
        return sys.stdin.readline().rstrip("\n")
    pw = getpass.getpass(prompt)
    if confirm:
        again = getpass.getpass("repeat it:        ")
        if pw != again:
            raise SystemExit("passphrases did not match")
    return pw


def read_totp(args, prompt: str = "authenticator code (6 digits): ") -> str:
    val = getattr(args, "totp", None)
    if val:
        return str(val).strip()
    if not sys.stdin.isatty():
        return sys.stdin.readline().strip()
    return input(prompt).strip()


def open_vault(args, require_unlocked: bool = True, mode: str = "passphrase",
               allow_setup: bool = False) -> tuple:
    """Open the vault. FAIL CLOSED on the second factor.

    * TOTP enrolled      -> the authenticator code is required, every time.
    * voice only         -> use ``brain unlock --voice`` (the passphrase alone is refused).
    * nothing enrolled   -> refused, except for the setup commands
                            (``allow_setup``: ``brain totp`` / ``brain enroll-voice``)
                            which exist precisely to enrol a factor.
    ``identity.allow_degraded`` remains the single explicit, audited override.
    """
    config = Config.load(getattr(args, "home", None))
    if getattr(args, "fast_kdf", False):
        config.fast_kdf = True
    vault = Vault(config)
    if not vault.initialized:
        raise SystemExit("no vault here - run `brain init` first "
                         f"(BRAIN_HOME={config.home})")
    if require_unlocked and not vault.is_unlocked():
        locked, wait = vault.locked_out()
        if locked:
            raise SystemExit(f"locked out after failed attempts; retry in {wait}s")
        passphrase = read_passphrase(args)
        try:
            mk = vault.unlock(passphrase)
        except PermissionError as exc:
            vault.register_failure("bad-passphrase")
            raise SystemExit(str(exc)) from exc
        vault.begin_provisional(mk)
        policy = vault.policy()
        secret = vault.load_totp_secret()
        has_voice = vault.has_voice()
        override = bool(policy.get("allow_degraded"))
        if secret and getattr(args, "recovery", None):
            # break-glass: a one-time recovery code instead of the authenticator
            if not vault.consume_recovery_code(str(args.recovery).strip()):
                w = vault.register_failure("bad-recovery-code")
                vault.discard_provisional()
                raise SystemExit("invalid recovery code" + (f" (locked out {w}s)" if w else ""))
            vault.meta_set("re_enrollment_required", True)
            session_mode = "recovery"
            degraded = True
        elif secret:
            code = read_totp(args)
            # ONE-TIME at the CLI too. `totp_verify` alone checks the maths, so
            # the same 6 digits unlocked command after command inside their
            # 30-second window; the API ceremony was fixed for this (audit B6)
            # but the main human route was not. Spend the step, then verify.
            from ..identity.totp import counter_for

            counter = counter_for(secret, code, min_counter=vault.totp_last_counter())
            if counter < 0:
                w = vault.register_failure("bad-totp")
                vault.discard_provisional()
                raise SystemExit("invalid or already-used authenticator code"
                                 + (f" (locked out {w}s)" if w else ""))
            vault.mark_totp_used(counter)
            session_mode = "totp"
            # "degraded" means a STRONGER factor exists and was not used - not
            # that none exists (that was a dead end for owners without a voiceprint).
            degraded = has_voice
        elif has_voice and not (override or allow_setup):
            vault.discard_provisional()
            raise SystemExit("second factor required: run `brain unlock --voice <wav>`, "
                             "or enrol an authenticator with `brain totp`")
        elif not (override or allow_setup):
            vault.discard_provisional()
            raise SystemExit("no second factor is enrolled, so the passphrase alone is "
                             "refused. Run `brain totp` once to enrol an authenticator app.")
        else:
            session_mode = mode if override else "setup"
            degraded = has_voice
        vault.register_success()
        vault.start_session(mk, mode=session_mode, degraded=degraded)
        vault.audit("session_unlock", {"mode": session_mode, "degraded": degraded,
                                       "via": "cli"})
    return config, vault


def open_memory(config: Config, vault: Vault) -> MemoryStore:
    """Open the store and pin it to this session's access level.

    The level decides two things: which vector class keys are loaded (so sealed
    vectors are cryptographically out of reach) and the classification ceiling
    applied to lexical hits. A degraded session - a stronger enrolled factor
    skipped during unlock - therefore gets genuinely narrower recall, not merely
    the same recall with a warning.
    """
    from ..security.classify import session_tier
    return MemoryStore(config, vault.session.mk,
                       access_level=session_tier(vault.session),
                       session=vault.session)


def warn_if_single_factor(ui: "UI", vault) -> None:
    """Warn when a full-tier session rests on ONE factor.

    On a vault with no voiceprint and no TOTP enrolled, the passphrase is the
    only factor that exists, so unlocking with it yields a full-tier session able
    to recall sensitive and restricted memories. Blocking that would make a fresh
    vault unusable (and treating it as degraded made an owner's own health notes
    unrecallable, which is why that was reverted). So it warns, every session.
    """
    if vault.session is None or vault.session.degraded:
        return
    try:
        has_voice = vault.has_voice()
        has_totp = bool(vault._identity().get("totp"))
    except Exception:
        return
    if has_voice or has_totp:
        return
    ui.warn("single-factor session: no voiceprint and no TOTP are enrolled, so "
            "your passphrase alone gave FULL access - including sensitive and "
            "restricted memories. Run `brain enroll-voice` and `brain totp` to "
            "require a second factor.")


def report_withheld(ui: "UI", store: MemoryStore) -> None:
    """Tell the user when matches were held back by the session tier.

    Without this, a tier filter turns into a silent "nothing matched", which is
    the worst possible failure mode: the user concludes the memory is gone
    rather than gated. Counts and classes only - never titles or bodies.
    """
    withheld = getattr(store, "last_withheld", None) or []
    if not withheld:
        return
    classes: dict = {}
    for w in withheld:
        classes[w.get("class", "?")] = classes.get(w.get("class", "?"), 0) + 1
    summary = ", ".join(f"{n} {k}" for k, n in sorted(classes.items()))
    ui.warn(f"{len(withheld)} match(es) withheld at session tier "
            f"'{store.level}' ({summary}). They exist but are not permitted in "
            f"this session - unlock with your voice factor to reach them.")


# --------------------------------------------------------------------------- #
# commands
# --------------------------------------------------------------------------- #
def cmd_init(args, ui: UI) -> int:
    config = Config.load(args.home)
    if args.fast_kdf:
        config.fast_kdf = True
    vault = Vault(config)
    if vault.initialized:
        return ui.err(f"a vault already exists at {config.home} "
                      "(delete BRAIN_HOME or use `brain device import`)")
    passphrase = read_passphrase(args, "choose a master passphrase: ", confirm=True)
    info = vault.initialize(passphrase, user=args.user, device_label=args.label)
    config.agent.setdefault("device_id", info["device_id"])
    config.save()
    ui.ok(f"vault created at {config.home}")
    ui.emit({"user": info["user"], "device_id": info["device_id"],
             "kdf": f"scrypt n={config.kdf_n} r=8 p=1",
             "crypto_backend": __import__("brain.crypto", fromlist=["x"]).backend(),
             "next": "brain totp  (links your authenticator app - required before the vault will open)"})
    if not args.no_recovery:
        from ..identity.ceremony import IdentityCeremony

        codes = IdentityCeremony(config, vault).enroll_recovery_codes(8)
        ui.warn("recovery codes - write these down NOW, they are shown once:")
        for i in range(0, len(codes), 2):
            ui.say("   " + "   ".join(codes[i:i + 2]))
    vault.audit("cli_init", {"user": args.user})
    vault.lock()
    return 0


def cmd_status(args, ui: UI) -> int:
    config = Config.load(args.home)
    vault = Vault(config)
    from ..crypto.envelope import backend as crypto_backend
    from ..memory.store import make_embedder

    payload: Dict[str, Any] = {
        "home": str(config.home),
        "initialized": vault.initialized,
        "crypto_backend": crypto_backend(),
        "version": __import__("brain").__version__,
    }
    if vault.initialized:
        payload.update({
            "user": vault.user, "device_id": vault.device_id,
            "devices": {k: v.get("label") for k, v in vault.devices().items()},
            "kdf": vault.data.get("kdf", {}).get("n"),
            "unlocked": vault.is_unlocked(),
            "voice_enrolled": bool((vault.data.get("voice") or {}).get("template")),
            "sync": dict(config.sync or {}),
            "updates": {k: v for k, v in (config.updates or {}).items() if k != "voice_model_override"},
            "agent": dict(config.agent or {}),
            "memory_db": str(config.memory_path),
            "audit_entries": len(vault.read_audit(10000)),
        })
        if args.unlock:
            passphrase = read_passphrase(args)
            try:
                vault.start_session(vault.unlock(passphrase), mode="passphrase", degraded=True)
            except PermissionError as exc:
                return ui.err(str(exc))
            memory = open_memory(config, vault)
            payload["voice"] = vault.voice_info()
            payload["memory"] = memory.stats()
            payload["embedder"] = memory.embedder.name
            memory.close()
            vault.lock()
    ui.emit(payload)
    return 0


def cmd_unlock(args, ui: UI) -> int:
    from ..identity.ceremony import CeremonyError, IdentityCeremony

    config = Config.load(args.home)
    vault = Vault(config)
    if not vault.initialized:
        return ui.err("no vault - run `brain init`")
    ceremony = IdentityCeremony(config, vault)
    passphrase = read_passphrase(args)

    submission = None
    if args.voice:
        challenge = ceremony.issue_challenge()
        ui.say(f'\033[36mspeak this challenge:\033[0m  "{challenge["text"]}"')
        if args.record:
            from ..util.audio import AudioError, record_microphone
            from ..util.misc import write_private as _wp

            try:
                audio = record_microphone(seconds=challenge_seconds(config))
            except AudioError as exc:
                return ui.err(str(exc))
            tmp = config.tmp_dir / f"challenge-{challenge['nonce'][:8]}.wav"
            from ..util.audio import write_wav

            write_wav(tmp, audio.samples, audio.sample_rate)
            submission = {"nonce": challenge["nonce"], "audio": str(tmp),
                          "bound": challenge["bound"]}
            _cleanup(tmp)
        else:
            submission = {"nonce": args.nonce or challenge["nonce"],
                          "audio": args.voice, "bound": args.bound or challenge["bound"]}
            if args.nonce and args.nonce != challenge["nonce"]:
                ui.warn("you passed --nonce that differs from the freshly issued challenge; "
                        "using yours (it must have been issued by `/challenge` earlier)")

    mode = "voice" if submission else ("totp" if args.totp else
                                       ("recovery" if args.recovery else "auto"))
    result = ceremony.unlock(passphrase, mode=mode, voice_submission=submission,
                             totp_code=args.totp, recovery_code=args.recovery)
    if not result.ok:
        return ui.err("; ".join(result.reasons) or "unlock failed")

    ui.ok(f"unlocked ({result.mode}"
          f"{', DEGRADED' if result.session.degraded else ''})")

    if getattr(args, "step_up", False):
        # `Session.step_up_ok` gates high-risk tools such as export_backup and is
        # read by the classifier. It used to have no setter at all, so the gate
        # could never open; the flag is consumed by the next high-risk tool call.
        session = getattr(vault, "session", None)
        if session is None:
            return ui.err("unlock succeeded but no session is available for step-up")
        session.step_up_ok = True
        from ..util.misc import now_ms as _now_ms

        session.step_up_at = _now_ms()
        vault.audit("step_up_granted", {"session": session.session_id,
                                        "via": "cli --step-up"})
        ui.ok("step-up granted: the next high-risk action is authorised")
    if args.json:
        print(json.dumps({"ok": True, **result.detail}, indent=2, default=str))
    if args.chat:
        from ..agent.agent import Brain
        from ..agent.repl import run_repl

        memory = open_memory(config, vault)
        brain = Brain(config, vault, memory)
        try:
            return run_repl(brain, verbose=args.verbose, banner=False)
        finally:
            memory.close()
    vault.lock()
    ui.say("session opened and closed (pass --chat to stay interactive)")
    return 0


def challenge_seconds(config: Config) -> float:
    return float(config.voice_config().get("challenge_seconds", 4.0))


def _cleanup(path: Path) -> None:
    try:
        path.unlink()
    except OSError:
        pass


def cmd_lock(args, ui: UI) -> int:
    config, vault = open_vault(args, require_unlocked=False)
    vault.lock()
    ui.ok("locked; in-memory key zeroised.")
    return 0


def cmd_enroll_voice(args, ui: UI) -> int:
    from ..identity.ceremony import CeremonyError, IdentityCeremony

    config, vault = open_vault(args, allow_setup=True)
    ceremony = IdentityCeremony(config, vault)
    samples: List[Any] = []
    n = args.samples
    if args.file:
        samples = list(args.file)
        n = len(samples)
    ui.say(f"enrolling {n} voice sample(s). Speak naturally, same mic you will use later.")
    while len(samples) < n:
        idx = len(samples) + 1
        if args.record:
            from ..util.audio import AudioError, record_microphone, write_wav

            ui.say(f"  sample {idx}/{n}: recording {args.seconds:.1f}s - speak now…")
            try:
                audio = record_microphone(seconds=args.seconds)
            except AudioError as exc:
                vault.lock()
                return ui.err(str(exc))
            tmp = config.tmp_dir / f"enroll-{idx}.wav"
            write_wav(tmp, audio.samples, audio.sample_rate)
            samples.append(str(tmp))
        else:
            path = input(f"  sample {idx}/{n} - path to a WAV file: ").strip()
            if not path:
                break
            samples.append(path)
    if len(samples) < max(1, min(n, 3)):
        vault.lock()
        return ui.err("need at least 3 samples (or pass --file a.wav b.wav c.wav)")
    try:
        report = ceremony.enroll_voice(samples[:n])
    except CeremonyError as exc:
        vault.lock()
        return ui.err(str(exc))
    for s in samples:
        if str(s).startswith(str(config.tmp_dir)):
            _cleanup(Path(s))
    ui.ok("voice template stored (encrypted with your master key)")
    ui.emit(report)
    if report.get("quality") != "good":
        ui.warn(f"enrolment quality: {report.get('quality')}")
    vault.lock()
    return 0


def cmd_voice_test(args, ui: UI) -> int:
    config, vault = open_vault(args)
    from ..identity.voice import VoiceVerifier

    verifier = VoiceVerifier(vault)
    if not vault.has_voice():
        vault.lock()
        return ui.err("no voice template enrolled")
    results = []
    for path in args.file:
        score = verifier.verify(path)
        results.append({"file": str(path), "score": score.score, "passed": score.passed,
                        "threshold": score.threshold})
        ui.say(f"  {Path(path).name:<28s} score={score.score:+.4f} "
               f"threshold={score.threshold:.4f} -> {'PASS' if score.passed else 'REJECT'}")
    if args.json:
        print(json.dumps(results, indent=2))
    vault.lock()
    return 0 if all(r["passed"] for r in results) else 2


def cmd_recovery(args, ui: UI) -> int:
    """Show how many recovery codes remain, or issue a fresh set.

    The vault had no user-facing reissue path at all: once the printed set was
    used up or exposed there was no remedy short of re-initialising.
    """
    from ..identity.ceremony import IdentityCeremony

    config, vault = open_vault(args)
    try:
        if args.show:
            remaining = vault.recovery_remaining()
            ui.ok(f"{remaining} recovery code(s) remaining")
            ui.emit({"remaining": remaining})
            return 0
        codes = IdentityCeremony(config, vault).reissue_recovery_codes(args.count)
        ui.ok(f"issued {len(codes)} new recovery codes. Every previous code is now invalid.")
        ui.say("Write these down, offline, and store them where you keep your passport:")
        for i, code in enumerate(codes, 1):
            ui.say(f"  {i:2d}. {code}")
        ui.emit({"codes": codes, "count": len(codes)})
        return 0
    finally:
        vault.lock()


def cmd_change_passphrase(args, ui: UI) -> int:
    """Rotate the vault passphrase, re-wrapping the master key for every device.

    ``Vault.rotate_passphrase`` existed but nothing reached it, so a user could
    not change the one secret that protects everything else.
    """
    import getpass as _getpass

    config, vault = open_vault(args)
    try:
        old = read_passphrase(args)
        if args.new_passphrase_stdin:
            new = sys.stdin.readline().rstrip("\n")
        else:
            new = _getpass.getpass("New passphrase: ")
            confirm = _getpass.getpass("Repeat the new passphrase: ")
            if new != confirm:
                return ui.err("the two entries did not match; nothing was changed")
        vault.rotate_passphrase(old, new)
        ui.ok("passphrase changed. Every device uses the new passphrase; the master key "
              "did not change, so existing memories, projects and backups still open.")
        return 0
    finally:
        vault.lock()


def cmd_totp(args, ui: UI) -> int:
    from ..identity.ceremony import IdentityCeremony
    from ..identity.totp import generate_secret, provisioning_uri
    from ..identity.totp import totp as totp_now
    from ..identity.totp import verify as totp_verify

    config, vault = open_vault(args, allow_setup=not args.show)
    ceremony = IdentityCeremony(config, vault)
    if args.show:
        secret = vault.load_totp_secret()
        if not secret:
            vault.lock()
            return ui.err("TOTP not enrolled")
        ui.emit({"secret": secret, "current_code": totp_now(secret)})
    elif vault.has_totp() and not args.replace:
        # A second factor is ALREADY enrolled, and this run cannot prove the new
        # secret works (non-interactive), nor did anyone ask to replace it.
        # The old code path replaced it silently: a cron job or a stray command
        # could invalidate the factor protecting the vault without a prompt
        # (credential-rotation backlog item).
        vault.lock()
        return ui.err("a TOTP factor is already enrolled. Replacing it invalidates your "
                      "current authenticator entry. Re-run with --replace to rotate it "
                      "interactively (the new secret is saved only after a code from your "
                      "app is confirmed).")
    elif sys.stdin.isatty():
        # Interactive: the secret is stored ONLY after you prove your app shows the
        # right code. A mistyped key can therefore never lock you out of your vault.
        secret = generate_secret()
        acct = args.account or vault.user
        ui.ok("Add Nila to your authenticator app (Google or Microsoft Authenticator):")
        ui.say("   1. Open the app and choose “Enter a setup key” (or add an account manually)")
        ui.say(f"   2. Account name: Nila     Key: {secret}")
        ui.say("   3. Type of key: time-based")
        ui.say(f"   (or open this link on a device with the app: {provisioning_uri(secret, acct)})")
        confirmed = False
        for _ in range(5):
            code = input("Type the 6-digit code your app shows now: ").strip()
            if totp_verify(secret, code):
                confirmed = True
                break
            ui.warn("that code did not match - check the key and your phone's clock, then retry")
        if not confirmed:
            vault.lock()
            return ui.err("not confirmed, so nothing was saved. Run this step again.")
        vault.store_totp(secret)
        vault.audit("totp_enrolled", {"account": acct, "confirmed": True})
        ui.ok("authenticator confirmed and saved. You will need its code every time you start Nila.")
    else:
        info = ceremony.enroll_totp(account=args.account)
        ui.ok("TOTP enrolled. Add this to your authenticator app:")
        ui.emit({"secret": info["secret"], "uri": info["uri"],
                 "current_code": totp_now(info["secret"])})
        ui.warn("the secret is stored encrypted; this is the only time it is printed.")
    vault.lock()
    return 0


def cmd_chat(args, ui: UI) -> int:
    from ..agent.agent import Brain
    from ..agent.repl import run_repl

    config, vault = open_vault(args)
    warn_if_single_factor(ui, vault)   # cmd_ask delegates here, so both are covered
    memory = open_memory(config, vault)
    brain = Brain(config, vault, memory)
    if args.verbose:
        ui.say(f"provider: {brain.provider.name if brain.provider.available() else 'local (offline)'}")
    try:
        if args.message:
            turn = brain.handle(args.message)
            if args.json:
                print(json.dumps(turn.to_dict(), indent=2, default=str))
            elif turn.ok:
                ui.say(turn.answer)
            else:
                return ui.err(turn.error)
            return 0
        return run_repl(brain, verbose=args.verbose)
    finally:
        memory.close()
        vault.lock()


def cmd_ask(args, ui: UI) -> int:
    args.message = " ".join(args.text)
    return cmd_chat(args, ui)


def cmd_instruct(args, ui: UI) -> int:
    """Manage standing instructions. THIS is the owner-only route.

    `brain instruct` is a human command; there is no code path from a tool, a
    file, a web page or the model to here. That is the whole point of #2: a
    standing rule is applied to every later turn, so only the owner may write
    one.
    """
    from ..memory.store import InstructionError

    config, vault = open_vault(args)
    memory = open_memory(config, vault)
    try:
        if args.action == "list":
            rows = memory.instructions()
            if args.json:
                ui.emit({"count": len(rows),
                         "instructions": [{"id": r.id, "text": r.body,
                                           "created_at": r.created_at} for r in rows]})
            elif not rows:
                ui.say("no standing instructions")
            else:
                for r in rows:
                    ui.say(f"  {r.id}  {r.body}")
                ui.say(f"\n({len(rows)} instruction(s))")
            return 0
        if args.action == "remove":
            target = args.id or (args.text[0] if args.text else "")
            if not target:
                return ui.err("which instruction? give its id: brain instruct list")
            ok = memory.remove_instruction(target)
            vault.audit("instruction_removed", {"id": target})
            return 0 if ok else ui.err(f"no such instruction: {target}")
        if args.action == "edit":
            target = args.id or (args.text[0] if args.text else "")
            text_parts = args.text[1:] if (not args.id and args.text) else args.text
            if not target:
                return ui.err("which instruction? give its id: brain instruct list")
            try:
                rec = memory.edit_instruction(target, " ".join(text_parts))
            except InstructionError as exc:
                vault.audit("instruction_refused", {"action": "edit", "reason": str(exc)})
                return ui.err(str(exc))
            vault.audit("instruction_edited", {"id": rec.id})
            ui.emit({"ok": True, "id": rec.id, "text": rec.body})
            return 0
        # add
        text = " ".join(args.text) if args.text else ""
        if not text.strip():
            return ui.err("say what the instruction should be, e.g. "
                          "brain instruct add \"call me Anna\"")
        try:
            rec = memory.add_instruction(text)
        except InstructionError as exc:
            vault.audit("instruction_refused", {"action": "add", "reason": str(exc)})
            return ui.err(str(exc))
        vault.audit("instruction_added", {"id": rec.id, "chars": len(rec.body)})
        ui.emit({"ok": True, "id": rec.id, "text": rec.body})
        return 0
    finally:
        memory.close()
        vault.lock()


def cmd_connectors(args, ui: UI) -> int:
    """The connectors screen, for a terminal.

    The one thing this command refuses to do is take a key as an argument: a
    command line is visible in the process list and in shell history. The key is
    read from a hidden prompt (or stdin for a script) and stored sealed in the
    vault; it is never echoed, printed or audited.
    """
    from ..agent.connectors import (CATEGORY_IDS, ConnectorError, ConnectorRegistry,
                                    StepUpRequired)

    config, vault = open_vault(args)
    memory = open_memory(config, vault)
    brain = None
    try:
        from ..agent.agent import Brain
        brain = Brain(config, vault, memory)
        reg = ConnectorRegistry(config, vault, brain, memory)
        action = args.action or "list"

        def approve(target: str, uses: int = 1) -> None:
            """The fresh-login check for one action.

            This process unlocked the vault seconds ago with the passphrase and
            an authenticator code, so that ceremony IS the fresh login. Only if
            the session is not that fresh (or the CLI is ever reused with an
            already-open vault) does this ask again.
            """
            try:
                reg.authorise(target, uses=uses)
            except StepUpRequired:
                reg.authorise(target, read_passphrase(args), read_totp(args), uses=uses)

        if action == "list":
            st = reg.status()
            if args.json:
                ui.emit(st)
                return 0
            ui.say(f"  signed in as: {st['auth_level']}"
                   + ("  (keys editable)" if st["can_edit_keys"] else
                      "  (keys need an authenticator login)"))
            ui.say("\n  AI services")
            for r in st["ai"]:
                key = ("key " + r["key_hint"] + " · " + r["key_source"]) if r["has_key"] else "no key"
                ui.say(f"    {'ON ' if r['on'] else 'off'}  {r['id']:<10} {r['label']:<22}"
                       f" {key:<32} {r['detail'] if not r['ready'] else 'ready'}")
                hosts = ", ".join(r["allowed_hosts"]) or ("this PC only" if r["egress"] == "local_only" else "-")
                u = r["usage"]
                used = (f"{u['requests']} today" + (f" of {u['allowed']}" if u.get("budgeted") else ""))
                ui.say(f"          hosts: {hosts}   used: {used}")
            ui.say("\n  Outside services")
            for r in st["integrations"]:
                if r.get("placeholder"):
                    continue
                ui.say(f"    {'ON ' if r['on'] else 'off'}  {r['id']:<12} "
                       f"hosts: {', '.join(r['allowed_hosts']) or '-'}   "
                       f"{r['key_source'] or 'no key needed'}")
            ui.say("\n  No payment, banking or card connectors exist in this build.")
            return 0

        if action == "approve":
            target = args.name[0] if args.name else ""
            if not target:
                return ui.err("which action? e.g. brain connectors approve connector:gemini:on")
            out = reg.authorise(target, read_passphrase(args), read_totp(args))
            ui.emit(out)
            return 0

        cid = args.name[0] if args.name else ""
        if not cid:
            return ui.err("name a connector: " + ", ".join(CATEGORY_IDS))

        if action in ("on", "off"):
            # The ceremony that opened this process seconds ago IS the fresh
            # login the switch requires, so no second prompt inside 30 s.
            out = reg.set_on(cid, action == "on", approved=False)
            ui.emit(out)
            return 0

        if action == "key":
            # Approve FIRST, then read the secret: reading it first would let a
            # failed approval leave a typed key sitting in the terminal buffer,
            # and would consume a stdin line that belongs to the prompt.
            #
            # ``--key-env`` exists for a script, not for convenience: it keeps the
            # secret out of argv AND out of the shell history.
            approve(f"connector:{cid}:key:set")
            secret = (os.environ.get(args.key_env, "") if args.key_env
                      else (sys.stdin.readline().rstrip("\n") if sys.stdin.isatty() is False
                            else getpass.getpass(f"{cid} API key (not shown): ")))
            if args.key_env and not secret.strip():
                return ui.err(f"environment variable {args.key_env} is empty/unset")
            if not secret.strip():
                return ui.err("no key entered")
            out = reg.set_key(cid, secret, approved=True)
            ui.emit(out)
            ui.say("  stored sealed in the vault; only the last four characters are kept "
                   "readable so you can tell keys apart")
            return 0

        if action == "remove-key":
            approve(f"connector:{cid}:key:remove")
            out = reg.remove_key(cid, approved=True)
            ui.emit(out)
            return 0

        if action == "test":
            approve(f"connector:{cid}:test")
            out = reg.test(cid, approved=True)
            ui.emit(out)
            ui.say(f"  counted against today's budget: "
                   f"{out['usage']['requests']} request(s) used")
            return 0

        return ui.err(f"unknown action: {action}")
    except StepUpRequired as exc:
        return ui.err(str(exc))
    except ConnectorError as exc:
        return ui.err(str(exc))
    finally:
        memory.close()
        vault.lock()


def cmd_remember(args, ui: UI) -> int:
    config, vault = open_vault(args)
    memory = open_memory(config, vault)
    text = " ".join(args.text) if args.text else (sys.stdin.read() if not sys.stdin.isatty() else "")
    if not text.strip():
        text = input("memory: ").strip()
    tags = [t for t in (args.tag or "").split(",") if t]
    rec = memory.remember(text, title=args.title or "", kind=args.kind, tags=tags)
    memory.close()
    vault.lock()
    ui.emit({"ok": True, "id": rec.id, "kind": rec.kind, "tags": rec.tags, "title": rec.title})
    return 0


def cmd_recall(args, ui: UI) -> int:
    config, vault = open_vault(args)
    warn_if_single_factor(ui, vault)
    memory = open_memory(config, vault)
    rows = memory.search(" ".join(args.query), limit=args.limit, kind=args.kind, tag=args.tag)
    withheld = list(getattr(memory, "last_withheld", []) or [])
    level = memory.level
    memory.close()
    vault.lock()
    if args.json:
        print(json.dumps([{"id": r.id, "kind": r.kind, "tags": r.tags, "title": r.title,
                           "body": r.body, "score": r.score} for r in rows], indent=2))
        return 0
    if withheld:
        # Counts and classes only - never titles or bodies.
        classes: dict = {}
        for w in withheld:
            classes[w.get("class", "?")] = classes.get(w.get("class", "?"), 0) + 1
        summary = ", ".join(f"{n} {k}" for k, n in sorted(classes.items()))
        ui.warn(f"{len(withheld)} match(es) withheld at session tier '{level}' "
                f"({summary}). They exist but are not permitted in this session; "
                f"unlock with your voice factor to reach them.")
    if not rows:
        ui.say("nothing matched." if not withheld else "nothing you may see at this tier matched.")
        return 0
    for r in rows:
        ui.say(f"\033[36m{r.score:.3f}\033[0m  {r.id}  ({r.kind}{', ' + ','.join(r.tags) if r.tags else ''})")
        for line in (r.body or r.title).splitlines()[:6]:
            ui.say(f"      {line}")
    return 0


def cmd_list(args, ui: UI) -> int:
    config, vault = open_vault(args)
    memory = open_memory(config, vault)
    rows = memory.list_records(kind=args.kind, tag=args.tag, limit=args.limit,
                               include_deleted=args.include_deleted)
    stats = memory.stats()
    memory.close()
    vault.lock()
    if args.json:
        print(json.dumps([{"id": r.id, "kind": r.kind, "tags": r.tags, "title": r.title,
                           "updated_at": r.updated_at, "deleted": r.deleted} for r in rows],
                         indent=2))
        return 0
    for r in rows:
        flag = " \033[31m[deleted]\033[0m" if r.deleted else ""
        ui.say(f"  {r.id}  {r.kind:<14s} {','.join(r.tags) or '-':<22s} {r.title[:60]}{flag}")
    ui.say(f"\n{stats['records']} records · {stats['pending_sync']} pending sync · "
           f"embedder {stats['embed_backend']}")
    return 0


def cmd_forget(args, ui: UI) -> int:
    config, vault = open_vault(args)
    memory = open_memory(config, vault)
    if args.all:
        if not args.yes:
            memory.close()
            vault.lock()
            return ui.err("refusing to delete everything without --yes")
        rows = memory.list_records(limit=100000, include_deleted=True)
        for r in rows:
            memory.delete(r.id, hard=args.hard)
        ui.ok(f"deleted {len(rows)} records")
    else:
        ok = memory.delete(args.id, hard=args.hard)
        if not ok:
            memory.close()
            vault.lock()
            return ui.err(f"no such record: {args.id}")
        ui.ok(f"{'hard-deleted' if args.hard else 'tombstoned'}: {args.id}")
    memory.close()
    vault.lock()
    return 0


def cmd_sync(args, ui: UI) -> int:
    from ..cloud.protocol import SyncEngine, SyncError

    config, vault = open_vault(args)
    memory = open_memory(config, vault)
    try:
        engine = SyncEngine(config, memory, vault)
    except SyncError as exc:
        memory.close()
        vault.lock()
        return ui.err(str(exc))
    if args.status:
        ui.emit(engine.status())
    else:
        try:
            report = engine.sync(dry_run=args.dry_run)
        except SyncError as exc:
            memory.close()
            vault.lock()
            return ui.err(str(exc))
        ui.emit(report)
        for warning in report.get("warnings") or []:
            ui.warn(warning)
        if report.get("errors"):
            ui.warn(f"{len(report['errors'])} error(s); first: {report['errors'][0]}")
            # A failed sync used to exit 0, so a scripted backup looked healthy.
            memory.close()
            vault.lock()
            return 1
    memory.close()
    vault.lock()
    return 0


def cmd_update(args, ui: UI) -> int:
    from ..updates.manager import UpdateManager

    config, vault = open_vault(args, require_unlocked=False)
    um = UpdateManager(config)
    if args.action == "list":
        ui.emit({"channels": um.list_channels(), **um.status()})
    elif args.action == "check":
        ui.emit(um.check(args.channel))
    elif args.action == "apply":
        result = um.apply(args.channel, force=args.force)
        ui.emit(result)
        if result.get("requires_restart"):
            ui.warn("a package artifact was installed; restart `brain` to run the new code")
        return 0 if result.get("ok") else 1
    elif args.action == "rollback":
        ui.emit(um.rollback())
    else:
        return ui.err(f"unknown action {args.action}")
    return 0


def cmd_channel_add(args, ui: UI) -> int:
    from ..updates.manager import UpdateManager

    config = Config.load(args.home)
    um = UpdateManager(config)
    result = um.add_channel(args.name, args.url, alg=args.alg, public=args.public or "",
                            key_id=args.key_id or "", mode=args.mode,
                            auto_apply=args.auto_apply)
    ui.emit(result)
    if result.get("warning"):
        ui.warn(result["warning"])
    return 0


def cmd_device(args, ui: UI) -> int:
    # `import` runs on a machine with NO vault yet, so it must not go through
    # open_vault(); every other action does.
    if args.action == "import":
        bundle_path = Path(args.bundle or "").expanduser()
        if not args.bundle or not bundle_path.exists():
            return ui.err(f"bundle not found: {args.bundle or '(none)'} "
                          "(use --path/to/bundle.json)")
        try:
            bundle = json.loads(bundle_path.read_bytes())
        except json.JSONDecodeError as exc:
            return ui.err(f"bundle is not valid JSON: {exc}")
        passphrase = read_passphrase(args)
        config = Config.load(args.home)
        if args.fast_kdf:
            config.fast_kdf = True
        vault = Vault(config)
        if vault.initialized:
            if not args.force:
                return ui.err("this device already has a vault; pass --force to replace it "
                              "(the existing one will be deleted)")
            config.identity_path.unlink(missing_ok=True)
            if config.memory_path.exists():
                config.memory_path.unlink()
            vault = Vault(config)
        try:
            info = vault.import_bundle(bundle, passphrase, device_label=args.label)
        except (PermissionError, ValueError, RuntimeError) as exc:
            return ui.err(str(exc))
        config.agent.setdefault("device_id", info["device_id"])
        config.save()
        ui.ok(f"enrolled as device {info['device_id']} ({info['label']})")
        ui.emit({**info, "next": "brain sync  (then brain chat)"})
        vault.audit("cli_device_import", {"device": info["device_id"]})
        vault.lock()
        return 0

    config, vault = open_vault(args)

    if args.action == "list":
        ui.emit({"this_device": vault.device_id, "devices": vault.devices()})
    elif args.action == "export":
        bundle = vault.export_bundle(label=args.label)
        out = Path(args.out).expanduser()
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(bundle, indent=2))
        os.chmod(out, 0o600)
        ui.ok(f"enrolment bundle written to {out}")
        ui.emit({"bytes": out.stat().st_size, "user": bundle["user"],
                 "exported_from": bundle["exported_from"],
                 "contains_plaintext": False,
                 "next": f"on the new device: brain device import {out}"})
        ui.warn("the bundle is ciphertext-only, but treat it as sensitive: it lets anyone "
                "who also knows your passphrase enrol a device.")
    elif args.action == "revoke":
        ok = vault.revoke_device(args.device_id)
        ui.emit({"revoked": ok, "device_id": args.device_id,
                 "note": "run `brain device rotate-key` so the revoked device's MK wrap is useless"
                 if ok else ""})
    elif args.action == "rotate-key":
        passphrase = read_passphrase(args, "current passphrase: ")
        info = vault.rotate_master_key(passphrase)
        ui.emit(info)
        ui.warn("now run `brain memory rekey` with the NEW master key")
    else:
        vault.lock()
        return ui.err(f"unknown action {args.action}")
    vault.lock()
    return 0


def cmd_backup(args, ui: UI) -> int:
    config, vault = open_vault(args)
    memory = open_memory(config, vault)
    out = Path(args.out).expanduser()
    out.parent.mkdir(parents=True, exist_ok=True)
    data = memory.export_encrypted_backup()
    out.write_bytes(data)
    os.chmod(out, 0o600)
    ident = Path(str(out) + ".identity.json")
    if args.with_identity:
        bundle = vault.export_bundle(label="backup")
        ident.write_text(json.dumps(bundle, indent=2))
        os.chmod(ident, 0o600)
    memory.close()
    vault.lock()
    ui.emit({"backup": str(out), "bytes": len(data),
             "identity_bundle": str(ident) if args.with_identity else None,
             "plaintext": False,
             "restore": "brain restore <backup> [--identity <bundle>]"})
    return 0


def cmd_restore(args, ui: UI) -> int:
    import shutil

    config = Config.load(args.home)
    if config.memory_path.exists() and not args.force:
        return ui.err(f"{config.memory_path} already exists (use --force to overwrite)")
    data = Path(args.backup).expanduser().read_bytes()
    header, _, rest = data.partition(b"\n")
    try:
        meta = json.loads(header)
    except json.JSONDecodeError:
        return ui.err("not a personal-brain backup (bad header)")
    # Format 2 adds the sealed project attachments after the DB snapshot. The
    # rpartition that used to split header/body/tag kept the attachments inside
    # `body`, so the sha256 check failed on every format-2 backup.
    attachments: dict = {}
    if "attachments_sha256" in meta:
        # <db>\n<attachments json>\n<tag>
        #
        # The DB snapshot is BINARY and can contain 0x0a bytes, so neither
        # partition nor rpartition can find the boundary on its own. The header
        # records the exact DB length; cut there and nothing else.
        size = int(meta.get("bytes") or 0)
        body = rest[:size]
        tail = rest[size + 1:] if len(rest) > size else b""
        att_blob, _, _tag = tail.rpartition(b"\n")
        from ..util.misc import sha256_hex as _sha

        if _sha(body) != meta.get("sha256"):
            return ui.err("backup database block failed its integrity check")
        if _sha(att_blob) != meta.get("attachments_sha256"):
            return ui.err("backup attachment block failed its integrity check")
        if att_blob.strip():
            try:
                attachments = json.loads(att_blob)
            except json.JSONDecodeError:
                return ui.err("backup attachment block is not valid JSON")
            if not isinstance(attachments, dict):
                return ui.err("backup attachment block is malformed")
    else:
        body, _, _tag = rest.rpartition(b"\n")
    if args.identity:
        bundle = json.loads(Path(args.identity).expanduser().read_bytes())
        passphrase = read_passphrase(args)
        vault = Vault(config)
        if vault.initialized and args.force:
            config.identity_path.unlink()
            vault = Vault(config)
        vault.import_bundle(bundle, passphrase, device_label=args.label or "restored")
    else:
        vault = Vault(config)
        if not vault.initialized:
            return ui.err("no vault to decrypt with; pass --identity <bundle>")
        passphrase = read_passphrase(args)
        vault.start_session(vault.unlock(passphrase), mode="passphrase", degraded=True)
    from ..util.misc import sha256_hex

    if sha256_hex(body) != meta.get("sha256"):
        vault.lock()
        return ui.err("backup integrity check failed (sha256 mismatch)")
    config.memory_path.write_bytes(body)
    os.chmod(config.memory_path, 0o600)
    restored_files = 0
    if attachments:
        from ..util.misc import b64d as _b64d

        root = config.memory_path.parent / "projects"
        root.mkdir(parents=True, exist_ok=True)
        for name, blob in attachments.items():
            if not name.endswith(".pbx") or "/" in name or "\\" in name:
                continue                     # never let a backup name a path
            try:
                (root / name).write_bytes(_b64d(blob))
                os.chmod(root / name, 0o600)
                restored_files += 1
            except (ValueError, OSError):
                continue
    memory = MemoryStore(config, vault.session.mk, session=vault.session)
    stats = memory.stats()
    memory.close()
    vault.lock()
    ui.ok("restored")
    ui.emit({"sha256": meta.get("sha256"), "records": stats["records"],
             "kinds": stats["kinds"], "embedder": stats["embed_backend"],
             "attachments_restored": restored_files,
             "attachments_expected": len(attachments)})
    return 0


def cmd_config(args, ui: UI) -> int:
    config = Config.load(args.home)
    stores = {"sync": config.sync, "updates": config.updates, "agent": config.agent,
              "identity": config.identity}
    if args.action == "show":
        ui.emit({"home": str(config.home), "fast_kdf": config.fast_kdf,
                 "session_timeout": config.session_timeout,
                 "session_absolute_timeout": config.session_absolute_timeout,
                 **{k: v for k, v in stores.items()}})
        return 0
    if not args.key:
        return ui.err("usage: brain config set <section.key> <value>")
    section, _, name = args.key.partition(".")
    store = stores.get(section)
    if store is None:
        return ui.err(f"unknown section '{section}' (choose from {sorted(stores)})")
    if args.action == "get":
        ui.emit({args.key: store if not name else store.get(name)})
        return 0
    value: Any = args.value
    if value is None:
        store.pop(name, None)
        config.save()
        ui.ok(f"unset {args.key}")
        return 0
    if value.lower() in ("true", "false"):
        value = value.lower() == "true"
    else:
        try:
            value = json.loads(value)
        except json.JSONDecodeError:
            pass
    store[name] = value
    config.save()
    ui.ok(f"set {args.key} = {value!r}")
    return 0


def cmd_audit(args, ui: UI) -> int:
    config = Config.load(args.home)
    vault = Vault(config)
    rows = vault.read_audit(args.limit)
    integrity = vault.verify_audit_chain()
    if args.json:
        print(json.dumps({"integrity": integrity, "entries": rows}, indent=2))
        return 0 if integrity.get("ok", True) else 3
    import datetime as _dt

    for r in rows:
        when = _dt.datetime.fromtimestamp(r["ts"] / 1000).strftime("%m-%d %H:%M:%S")
        ui.say(f"{when}  {r['event']:<24s} {dumps(r.get('data'))[:90]}")
    ui.say(f"\nchain integrity: {integrity}")
    if integrity.get("legacy_unprotected"):
        ui.warn(f"{integrity['legacy_unprotected']} older entries predate the "
                "payload-bound chain: their `data` was never hashed and cannot be verified.")
    return 0


def cmd_doctor(args, ui: UI) -> int:
    """Self-test: verifies crypto, storage, voice and sync paths locally."""
    import shutil
    import tempfile

    from ..crypto.envelope import backend, decrypt, encrypt
    from ..identity.voice import MfccVoiceBackend, load_model

    checks: List[Dict[str, Any]] = []

    def check(name: str, fn):
        try:
            detail = fn()
            checks.append({"check": name, "ok": True, "detail": detail})
        except Exception as exc:
            checks.append({"check": name, "ok": False,
                           "detail": f"{type(exc).__name__}: {exc}"})

    def c_crypto():
        key = os.urandom(32)
        ct = encrypt(b"doctor", key, aad=b"x")
        assert decrypt(ct, key, aad=b"x") == b"doctor"
        bad = bytearray(ct)
        bad[-1] ^= 1
        try:
            decrypt(bytes(bad), key, aad=b"x")
            raise AssertionError("tamper not detected")
        except Exception as exc:
            if "tamper not detected" in str(exc):
                raise
        return f"backend={backend()}"

    def c_voice_model():
        model = load_model()
        if not model.available:
            raise AssertionError("voice_model.json missing or unreadable")
        ev = model.evaluated
        return (f"backend={model.name} keep={model.keep} threshold={model.threshold} "
                f"eer={ev.get('eer')} at_balanced={ev.get('at_balanced')}")

    def c_optional():
        present = []
        for mod in ("cryptography", "numpy", "soundfile", "sounddevice", "keyring",
                    "sentence_transformers"):
            if __import__("brain.util.misc", fromlist=["x"]).try_import(mod):
                present.append(mod)
        return f"installed: {present or 'none (running pure-stdlib)'}"

    def c_roundtrip():
        tmp = tempfile.mkdtemp(prefix="brain-doctor-")
        try:
            cfg = Config.load(Path(tmp) / "home")
            cfg.fast_kdf = True
            v = Vault(cfg)
            v.initialize("doctor-passphrase", "doctor", "doctor-device")
            m = MemoryStore(cfg, v.session.mk)
            rec = m.remember("doctor probe", tags=["doctor"])
            assert m.get(rec.id).body == "doctor probe"
            assert m.search("doctor probe")
            from ..cloud.protocol import LocalBlobStore, SyncEngine

            engine = SyncEngine(cfg, m, v, LocalBlobStore(Path(tmp) / "cloud"))
            report = engine.sync()
            assert report["pushed"] == 1, report
            m.close()
            v.lock()
            return "init -> remember -> search -> e2ee sync all ok"
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    check("crypto envelope", c_crypto)
    check("voice calibration model", c_voice_model)
    check("end-to-end vault+memory+sync", c_roundtrip)
    check("optional dependencies", c_optional)

    config = Config.load(args.home)
    if Vault(config).initialized:
        def c_real():
            v = Vault(config)
            return (f"vault ok: user={v.user} device={v.device_id} "
                    f"devices={len(v.devices())} audit={v.verify_audit_chain()}")

        check("installed vault", c_real)

    failed = [c for c in checks if not c["ok"]]
    for c in checks:
        mark = "\033[32mPASS\033[0m" if c["ok"] else "\033[31mFAIL\033[0m"
        print(f"  [{mark}] {c['check']:<32s} {c['detail']}")
    if args.json:
        print(json.dumps(checks, indent=2))
    return 1 if failed else 0


def cmd_report(args, ui: UI) -> int:
    from .. import diagnostics
    from ..agent.agent import Brain

    config, vault = open_vault(args)
    memory = open_memory(config, vault)
    brain = Brain(config, vault, memory)
    rep = diagnostics.report(brain)
    if args.json:
        print(json.dumps(rep, indent=2, default=str))
    else:
        print(diagnostics.report_text(rep))
    memory.close()
    vault.lock()
    return 0


def cmd_challenge(args, ui: UI) -> int:
    """Issue a voice challenge without unlocking (used with `brain unlock --voice`)."""
    config = Config.load(args.home)
    vault = Vault(config)
    if not vault.initialized:
        return ui.err("no vault - run `brain init`")
    if not vault.has_voice():
        return ui.err("no voice template enrolled yet - run `brain enroll-voice`. "
                      "(the check is ciphertext-only; nothing was decrypted)")
    from ..identity.ceremony import IdentityCeremony

    ch = IdentityCeremony(config, vault).issue_challenge(style=args.style)
    if args.json:
        print(json.dumps(ch, indent=2))
    else:
        ui.say(f'say: "{ch["text"]}"')
        ui.emit({"nonce": ch["nonce"], "bound": ch["bound"], "expires_at": ch["expires_at"]})
        ui.say("\nthen:  brain unlock --voice recording.wav --nonce "
               f"{ch['nonce']} --bound {ch['bound']}")
    return 0


# --------------------------------------------------------------------------- #
# permissions: the human side of the explicit-affirmation boundary
# --------------------------------------------------------------------------- #
def _broker(config):
    from ..security.permission import Broker

    return Broker(path=config.home / "permissions.json")


def cmd_permission(args, ui: UI) -> int:
    from ..security.permission import CAPABILITIES

    config = Config.load(args.home)
    broker = _broker(config)
    action = args.action

    # The second positional means different things per action: a prompt id for
    # `affirm`, a capability name for everything else. Accepting both spellings
    # keeps `brain permission affirm prm_xxx` working, which is the exact
    # command Nila prints when she refuses something.
    second = (args.capability or "").strip()
    prompt = (args.prompt or "").strip()
    if action == "affirm":
        if not prompt and second:
            prompt, args.capability = second, ""
    elif second.startswith("prm_"):
        prompt, args.capability = prompt or second, ""
    args.prompt = prompt

    if action == "panic":
        # The emergency switch. Unlike `revoke`, the latch also blocks NEW
        # grants until a human clears it - so a compromised session cannot
        # re-grant itself access after being revoked.
        if getattr(args, "clear", False):
            cleared = broker.clear_panic()
            ui.say("panic latch cleared - permissions work again." if cleared
                   else "no panic latch was set.")
            if cleared:
                ui.say("every previous grant stayed revoked; re-affirm what you need.")
            if args.json:
                print(json.dumps({"ok": True, "cleared": cleared,
                                  "grants": len(broker.grants())}))
            return 0
        latch = broker.panicked()
        result = broker.panic(getattr(args, "reason", "") or "")
        ui.say("\033[31mPANIC: all permissions revoked and latched off.\033[0m")
        ui.say("nothing host-facing works until `brain permission panic --clear`.")
        ui.say("new grants are refused too, including standing ones.")
        if latch:
            ui.say("(a latch was already set - revoking again)")
        if args.json:
            print(json.dumps({"ok": True, "latched": True, **result}))
        return 0

    if action == "capabilities":
        rows = [{"capability": k, **v} for k, v in sorted(CAPABILITIES.items())]
        if args.json:
            print(json.dumps(rows, indent=2))
        else:
            ui.say("capability     risk     durable?  what it allows")
            ui.say("─" * 78)
            for r in rows:
                ui.say(f"{r['capability']:<14s} {r['risk']:<8s} "
                       f"{'yes' if r['durable_ok'] else 'NEVER':<9s} {r['label']}")
                ui.say(f"{'':<32s}{r['detail']}")
        return 0

    if action == "list":
        broker.prune()
        rows = broker.ledger()
        if args.json:
            print(json.dumps(rows, indent=2))
        elif not rows:
            ui.say("no permissions recorded. Nila can read and search her own vault,")
            ui.say("but she cannot touch files, photos, the shell or the network")
            ui.say("until you affirm each capability.")
        else:
            ui.say(f"{'capability':<14s} {'kind':<9s} {'active':<7s} {'uses':<5s} scope")
            ui.say("─" * 78)
            for r in rows:
                mark = "\033[32myes\033[0m" if r["active"] else "\033[90mno\033[0m "
                ui.say(f"{r['capability']:<14s} {r['kind']:<9s} {mark:<16s} "
                       f"{r['uses']:<5d} {r['scope']}")
                if r["purpose"]:
                    ui.say(f"{'':<14s} purpose: {r['purpose']}")
        return 0

    if action == "grant":
        if not args.capability:
            return ui.err("usage: brain permission grant <capability> [--scope PATH] [--purpose TEXT]")
        if args.capability not in CAPABILITIES:
            return ui.err(f"unknown capability '{args.capability}'. "
                          f"Try: brain permission capabilities")
        d = broker.grant_durable(args.capability, args.scope or "*", args.purpose or "")
        if d.allowed:
            ui.ok(f"standing grant recorded: {args.capability} on {args.scope or '*'}")
            ui.warn("this expires in 7 days. Revoke any time with "
                    "`brain permission revoke`.")
        else:
            return ui.err(d.reason)
        return 0

    if action == "deny":
        if not args.capability:
            return ui.err("usage: brain permission deny <capability> [--scope PATH]")
        d = broker.deny(args.prompt or "", standing=args.standing,
                        capability=args.capability, scope=args.scope or "*")
        if args.standing:
            ui.ok(f"standing refusal recorded for {args.capability} on {args.scope or '*'}. "
                  f"Nila will stop asking.")
        return 0 if d.allowed is False else 1

    if action == "revoke":
        if not args.capability:
            return ui.err("usage: brain permission revoke <capability> [--scope PATH]")
        n = broker.revoke(args.capability, args.scope)
        ui.ok(f"revoked {n} grant(s) for {args.capability}"
              + (f" on {args.scope}" if args.scope else ""))
        return 0

    if action == "affirm":
        if not args.prompt:
            return ui.err("usage: brain permission affirm <prompt-id>")
        d = broker.affirm(args.prompt, granted_by="cli", remember=args.remember)
        if d.allowed:
            ui.ok(f"affirmed {d.capability} on {d.scope}"
                  + (" as a standing grant" if args.remember else " for one use only"))
            return 0
        return ui.err(d.reason)

    return ui.err(f"unknown permission action: {action}")


def cmd_serve(args, ui: UI) -> int:
    from ..api.gateway import serve

    config, vault = open_vault(args)
    memory = open_memory(config, vault)
    return serve(config, vault, memory, host=args.host, port=args.port, token=args.token,
                 open_browser=bool(getattr(args, "open", False)),
                 show_token=bool(getattr(args, "show_token", False)))


def cmd_keygen(args, ui: UI) -> int:
    from ..updates.manifest import generate_signing_key

    keys = generate_signing_key()
    if args.out:
        out = Path(args.out).expanduser()
        write = out.write_text(json.dumps(keys, indent=2))
        os.chmod(out, 0o600)
        ui.ok(f"signing key written to {out} (keep the private half secret)")
    ui.emit(keys)
    return 0


# --------------------------------------------------------------------------- #
# parser
# --------------------------------------------------------------------------- #
def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="brain",
                                description="Nila - a local-first, end-to-end encrypted "
                                            "personal AI agent")
    p.add_argument("--home", default=None, help="BRAIN_HOME override (default ~/.personal-brain)")
    p.add_argument("--json", action="store_true", help="machine-readable output")
    p.add_argument("--quiet", action="store_true")
    p.add_argument("--fast-kdf", action="store_true",
                   help="use a weaker scrypt cost (tests/benchmarks only!)")
    p.add_argument("--version", action="version",
                   version=f"personal-brain {__import__('brain').__version__}")
    sub = p.add_subparsers(dest="command", required=True)

    def add_auth(sp):
        sp.add_argument("--passphrase", default=None, help=argparse.SUPPRESS)
        sp.add_argument("--passphrase-env", default=None, metavar="VAR",
                        help="read the passphrase from this environment variable")
        sp.add_argument("--passphrase-stdin", action="store_true",
                        help="read the passphrase from stdin")
        existing = {o for a in sp._actions for o in a.option_strings}   # `unlock` has its own
        if "--totp" not in existing:
            sp.add_argument("--totp", default=None, metavar="CODE",
                            help="authenticator code (otherwise you are prompted)")
        if "--recovery" not in existing:
            sp.add_argument("--recovery", default=None, metavar="CODE",
                            help="one-time recovery code, used instead of the authenticator")

    sp = sub.add_parser("init", help="create the vault and enrol recovery codes")
    sp.add_argument("--user", default="owner")
    sp.add_argument("--label", default="", help="device label")
    sp.add_argument("--no-recovery", action="store_true")
    add_auth(sp)
    sp.set_defaults(func=cmd_init)

    sp = sub.add_parser("status", help="show vault/config/memory status")
    sp.add_argument("--unlock", action="store_true", help="also report memory + voice details")
    add_auth(sp)
    sp.set_defaults(func=cmd_status)

    sp = sub.add_parser("unlock", help="run the authentication ceremony")
    sp.add_argument("--voice", metavar="WAV", help="path to the recorded challenge")
    sp.add_argument("--nonce", help="challenge nonce (from `/challenge` or `brain challenge`)")
    sp.add_argument("--bound", help="challenge binding HMAC")
    sp.add_argument("--record", action="store_true", help="record from the microphone")
    sp.add_argument("--seconds", type=float, default=4.0)
    sp.add_argument("--totp", help="6-digit TOTP code (degraded session)")
    sp.add_argument("--recovery", help="recovery code (break-glass)")
    sp.add_argument("--chat", action="store_true", help="stay in the REPL after unlocking")
    sp.add_argument("--step-up", action="store_true",
                    help="mark this session as re-authenticated, authorising ONE "
                         "high-risk action (e.g. /export in the REPL)")
    sp.add_argument("--verbose", action="store_true")
    add_auth(sp)
    sp.set_defaults(func=cmd_unlock)

    sp = sub.add_parser("lock", help="lock and zeroise the session")
    sp.set_defaults(func=cmd_lock)

    sp = sub.add_parser("enroll-voice", help="enrol the voice template")
    sp.add_argument("--file", nargs="+", help="WAV files to enrol from")
    sp.add_argument("--record", action="store_true", help="record from the microphone")
    sp.add_argument("--samples", type=int, default=3)
    sp.add_argument("--seconds", type=float, default=4.0)
    add_auth(sp)
    sp.set_defaults(func=cmd_enroll_voice)

    sp = sub.add_parser("voice-test", help="score sample files without unlocking a session")
    sp.add_argument("file", nargs="+")
    add_auth(sp)
    sp.set_defaults(func=cmd_voice_test)

    sp = sub.add_parser("recovery", help="show or reissue break-glass recovery codes")
    sp.add_argument("--show", action="store_true", help="only report how many remain")
    sp.add_argument("--count", type=int, default=8, help="how many codes to issue")
    add_auth(sp)
    sp.set_defaults(func=cmd_recovery)

    sp = sub.add_parser("change-passphrase", help="rotate the vault passphrase")
    sp.add_argument("--new-passphrase-stdin", action="store_true",
                    help="read the new passphrase from stdin (scripting)")
    add_auth(sp)
    sp.set_defaults(func=cmd_change_passphrase)

    sp = sub.add_parser("totp", help="enrol or show the TOTP second factor")
    sp.add_argument("--show", action="store_true")
    sp.add_argument("--replace", action="store_true",
                    help="replace an already-enrolled TOTP factor (interactive confirmation)")
    sp.add_argument("--account", default=None)
    add_auth(sp)
    sp.set_defaults(func=cmd_totp)

    sp = sub.add_parser("instruct", help="add, list, edit or remove standing instructions")
    sp.add_argument("action", choices=["add", "list", "edit", "remove"], nargs="?", default="list")
    sp.add_argument("text", nargs="*", help="the instruction text (for add/edit)")
    sp.add_argument("--id", default=None, help="instruction id (for edit/remove)")
    add_auth(sp)
    sp.set_defaults(func=cmd_instruct)

    sp = sub.add_parser("connectors", help="which AI services and outside services are on")
    sp.add_argument("action", nargs="?",
                    choices=["list", "on", "off", "key", "remove-key", "test", "approve"],
                    default="list")
    sp.add_argument("name", nargs="*", help="connector id, e.g. gemini")
    sp.add_argument("--key-env", default=None,
                    help="read the API key from this environment variable (for scripts)")
    add_auth(sp)
    sp.set_defaults(func=cmd_connectors)

    sp = sub.add_parser("chat", help="interactive text REPL")
    sp.add_argument("-m", "--message", default=None, help="single turn, then exit")
    sp.add_argument("--verbose", action="store_true")
    add_auth(sp)
    sp.set_defaults(func=cmd_chat)

    sp = sub.add_parser("ask", help="one-shot question")
    sp.add_argument("text", nargs="+")
    sp.add_argument("--verbose", action="store_true")
    add_auth(sp)
    sp.set_defaults(func=cmd_ask)

    sp = sub.add_parser("remember", help="store a memory")
    sp.add_argument("text", nargs="*")
    sp.add_argument("--kind", default="note")
    sp.add_argument("--tag", default="")
    sp.add_argument("--title", default="")
    add_auth(sp)
    sp.set_defaults(func=cmd_remember)

    sp = sub.add_parser("recall", help="hybrid search over memory")
    sp.add_argument("query", nargs="+")
    sp.add_argument("--limit", type=int, default=5)
    sp.add_argument("--kind")
    sp.add_argument("--tag")
    add_auth(sp)
    sp.set_defaults(func=cmd_recall)

    sp = sub.add_parser("list", help="list memories")
    sp.add_argument("--kind")
    sp.add_argument("--tag")
    sp.add_argument("--limit", type=int, default=25)
    sp.add_argument("--include-deleted", action="store_true")
    add_auth(sp)
    sp.set_defaults(func=cmd_list)

    sp = sub.add_parser("forget", help="delete a memory")
    sp.add_argument("id", nargs="?")
    sp.add_argument("--hard", action="store_true")
    sp.add_argument("--all", action="store_true")
    sp.add_argument("--yes", action="store_true")
    add_auth(sp)
    sp.set_defaults(func=cmd_forget)

    sp = sub.add_parser("sync", help="end-to-end encrypted cloud sync")
    sp.add_argument("--dry-run", action="store_true")
    sp.add_argument("--status", action="store_true")
    add_auth(sp)
    sp.set_defaults(func=cmd_sync)

    sp = sub.add_parser("update", help="update channel operations")
    sp.add_argument("action", choices=["list", "check", "apply", "rollback"])
    sp.add_argument("--channel", default=None)
    sp.add_argument("--force", action="store_true")
    sp.set_defaults(func=cmd_update)

    sp = sub.add_parser("update-channel-add", help="pin an update channel")
    sp.add_argument("name")
    sp.add_argument("url")
    sp.add_argument("--alg", default="ed25519")
    sp.add_argument("--public", default="")
    sp.add_argument("--key-id", default="")
    sp.add_argument("--mode", default="tofu", choices=["strict", "tofu", "insecure"])
    sp.add_argument("--auto-apply", action="store_true")
    sp.set_defaults(func=cmd_channel_add)

    sp = sub.add_parser("keygen", help="generate an update signing key")
    sp.add_argument("--out", default="")
    sp.set_defaults(func=cmd_keygen)

    sp = sub.add_parser("device", help="multi-device enrolment")
    sp.add_argument("action", choices=["list", "export", "import", "revoke", "rotate-key"])
    sp.add_argument("--out", default="brain-bundle.json")
    sp.add_argument("--bundle", default="")
    sp.add_argument("--label", default="")
    sp.add_argument("--device-id", default="")
    sp.add_argument("--force", action="store_true", help="replace an existing vault on import")
    add_auth(sp)
    sp.set_defaults(func=cmd_device)

    sp = sub.add_parser("backup", help="write an encrypted backup")
    sp.add_argument("out")
    sp.add_argument("--with-identity", action="store_true",
                    help="also export the enrolment bundle (needed to restore on a new device)")
    add_auth(sp)
    sp.set_defaults(func=cmd_backup)

    sp = sub.add_parser("restore", help="restore an encrypted backup")
    sp.add_argument("backup")
    sp.add_argument("--identity", default="")
    sp.add_argument("--force", action="store_true")
    sp.add_argument("--label", default="")
    add_auth(sp)
    sp.set_defaults(func=cmd_restore)

    sp = sub.add_parser("config", help="read/write runtime config")
    sp.add_argument("action", choices=["show", "get", "set"])
    sp.add_argument("key", nargs="?")
    sp.add_argument("value", nargs="?")
    sp.set_defaults(func=cmd_config)

    sp = sub.add_parser("audit", help="tail the hash-chained audit journal")
    sp.add_argument("--limit", type=int, default=25)
    sp.set_defaults(func=cmd_audit)

    sp = sub.add_parser("doctor", help="self-test crypto, voice model, storage and sync")
    sp.set_defaults(func=cmd_doctor)

    sp = sub.add_parser("report", help="health report: what works, what is blocked, how to fix it")
    sp.add_argument("--json", action="store_true")
    add_auth(sp)
    sp.set_defaults(func=cmd_report)

    sp = sub.add_parser("challenge", help="issue a voice liveness challenge")
    sp.add_argument("--style", default="digits", choices=["digits", "words"])
    sp.set_defaults(func=cmd_challenge)

    sp = sub.add_parser("permission",
                        help="manage what Nila may touch on this device")
    sp.add_argument("action", choices=["list", "grant", "revoke", "deny", "affirm",
                                       "capabilities", "panic"])
    sp.add_argument("capability", nargs="?", default="")
    sp.add_argument("--scope", default="", help="path, host or command the grant covers")
    sp.add_argument("--purpose", default="", help="shown in the prompt and the ledger")
    sp.add_argument("--prompt", default="", help="prompt id from a refused tool call")
    sp.add_argument("--remember", action="store_true",
                    help="turn a one-shot affirmation into a 7-day standing grant")
    sp.add_argument("--standing", action="store_true",
                    help="remember this refusal so Nila stops asking")
    sp.add_argument("--tool", default="",
                    help="name of the requester, shown in the prompt")
    sp.add_argument("--clear", action="store_true",
                    help="with `panic`: release the latch (grants stay revoked)")
    sp.add_argument("--reason", default="", help="with `panic`: recorded in the audit log")
    sp.set_defaults(func=cmd_permission)

    sp = sub.add_parser("serve", help="run the localhost JSON API (text + voice auth)")
    sp.add_argument("--host", default="127.0.0.1")
    sp.add_argument("--port", type=int, default=8765)
    sp.add_argument("--token", default="")
    sp.add_argument("--open", action="store_true",
                    help="open the dashboard in your browser (token is not printed)")
    sp.add_argument("--show-token", action="store_true",
                    help="print the access token (avoid: it lands in terminal history)")
    add_auth(sp)
    sp.set_defaults(func=cmd_serve)

    return p


def main(argv: Optional[List[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    ui = UI(quiet=getattr(args, "quiet", False), json_out=getattr(args, "json", False))
    try:
        return int(args.func(args, ui) or 0)
    except KeyboardInterrupt:
        print()
        return 130
    except SystemExit as exc:
        if exc.code and str(exc.code) != "0":
            return ui.err(str(exc.code))
        return 0
    except Exception as exc:  # never dump a traceback on the user
        import traceback

        if os.environ.get("BRAIN_DEBUG"):
            traceback.print_exc()
        return ui.err(f"{type(exc).__name__}: {exc}")


if __name__ == "__main__":
    raise SystemExit(main())
