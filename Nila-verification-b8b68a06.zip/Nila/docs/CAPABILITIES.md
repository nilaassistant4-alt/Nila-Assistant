# What Nila can do (v0.1)

The dashboard's *What Nila can do* list is computed from the real state of the system. This page
explains the states and how to move an item toward **ready**.

| State | Meaning |
|---|---|
| ready (`possible`) | works now |
| asks you first (`needs_permission`) | allowed, but every use needs your approval in the Approvals box |
| needs setup (`needs_setup`) | something must be installed or configured |
| blocked | refused by policy, a limit, or the panic latch |
| not built yet (`planned`) | on the roadmap; do not expect it |

## Items

| Item | How to enable / notes |
|---|---|
| Remember, projects, attachments | always ready while the vault is unlocked |
| Built-in engine | always ready; basic intent matching, not a language model |
| Local AI (Ollama) | install Ollama, `ollama pull llama3.2:3b`, keep it running. Change model: `brain config set agent.local_model <name>` |
| Online AI (Gemini) | set `GEMINI_API_KEY` (Windows user variable); set limits `agent.online_daily_requests`, `agent.online_rpm`, `agent.online_stop_pct`; model `agent.online_model`; key variable name `agent.online_key_env` |
| Auto-online | off by default. `brain config set agent.auto_online true` lets Nila go online by itself only when no local model is running (and the message is not private) |
| Read files | approve each time; choose shared folders with `agent.dashboard_roots` |
| Run a command | approve each time; one plain command; runs in `<data>\workspace` |
| Photos | approve each time; metadata only |
| Export | fresh login check each time |
| Outside services | off by default; each must be enabled and approved |

## Routing rules

1. **Auto** (default): this PC if Ollama is running, otherwise the built-in engine.
2. **This PC only**: never leaves the device.
3. **Online**: only if a key is set, the message contains no private data, the daily and per-minute
   budget allow it, and the provider is not cooling down after a rate-limit reply. Otherwise it
   answers locally and says why.

## Settings reference (`python brain.py config set <key> <value>`)

`agent.local_model`, `agent.ollama_url` (must be 127.0.0.1), `agent.online_provider`,
`agent.online_model`, `agent.online_key_env`, `agent.online_daily_requests`, `agent.online_rpm`,
`agent.online_stop_pct`, `agent.auto_online`, `agent.route_default` (auto | local | online),
`agent.dashboard_roots`.
