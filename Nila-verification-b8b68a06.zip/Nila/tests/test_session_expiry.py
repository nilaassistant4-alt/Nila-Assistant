"""Session expiry must be exact, non-resurrectable, and tied to user activity."""
from __future__ import annotations

import time

from brain.api.gateway import Gateway
from brain.agent.agent import Brain
from brain.agent.providers import Completion
from brain.config import Config, SESSION_ABSOLUTE_TIMEOUT_SECONDS, SESSION_TIMEOUT_SECONDS
from brain.memory.vault import Session
from brain.util.misc import now_ms


def test_session_expires_at_the_exact_idle_or_absolute_deadline():
    idle_limited = Session(mk=b"k" * 32, session_id="s", started_at=0, expires_at=100)
    assert not idle_limited.expired(now=99)
    assert idle_limited.expired(now=100), "expires_at is an exclusive upper bound"

    absolute_limited = Session(mk=b"k" * 32, session_id="s", started_at=0,
                               expires_at=200, absolute_expires_at=100)
    assert not absolute_limited.expired(now=99)
    assert absolute_limited.expired(now=100), "absolute maximum is also exclusive"


def test_monotonic_deadline_cannot_be_extended_by_wall_clock_rollback(monkeypatch):
    session = Session(mk=b"k" * 32, session_id="s", started_at=0, expires_at=10_000,
                      absolute_expires_at=20_000, expires_at_monotonic=30.0,
                      absolute_expires_at_monotonic=20.0)
    monkeypatch.setattr("brain.memory.vault.now_ms", lambda: 0)
    monkeypatch.setattr("brain.memory.vault.time.monotonic", lambda: 20.0)
    assert session.expired(), "absolute monotonic deadline must win if wall time moves back"


def test_wall_clock_rollback_still_locks_vault_and_store(vault, memory, monkeypatch):
    session = vault.session
    key = session.mk
    wall_now = now_ms()
    mono_now = time.monotonic()
    session.expires_at = wall_now + 60_000
    session.absolute_expires_at = wall_now + 120_000
    session.expires_at_monotonic = mono_now - 1
    session.absolute_expires_at_monotonic = mono_now + 120
    monkeypatch.setattr("brain.memory.vault.now_ms", lambda: wall_now - 10_000)

    assert vault.is_unlocked() is False
    assert vault._session is None
    assert not any(key)
    assert memory._closed


def test_v02_session_timeout_defaults_and_config_round_trip(tmp_path):
    config = Config.load(tmp_path)
    assert config.session_timeout == SESSION_TIMEOUT_SECONDS == 2 * 60 * 60
    assert config.session_absolute_timeout == SESSION_ABSOLUTE_TIMEOUT_SECONDS == 12 * 60 * 60

    config.session_timeout = 90
    config.session_absolute_timeout = 600
    config.save()
    loaded = Config.load(tmp_path)
    assert loaded.session_timeout == 90
    assert loaded.session_absolute_timeout == 600


def test_legacy_default_migrates_but_custom_idle_timeout_is_preserved(tmp_path):
    config = Config.load(tmp_path)
    config.config_path.write_text(
        '{"config_version": 1, "session_timeout": 900}', encoding="utf-8")
    migrated = Config.load(tmp_path)
    assert migrated.session_timeout == SESSION_TIMEOUT_SECONDS
    assert migrated.session_absolute_timeout == SESSION_ABSOLUTE_TIMEOUT_SECONDS

    config.config_path.write_text(
        '{"config_version": 1, "session_timeout": 600}', encoding="utf-8")
    custom = Config.load(tmp_path)
    assert custom.session_timeout == 600


def test_touch_does_not_resurrect_an_expired_session(vault, memory):
    session = vault.session
    key = session.mk
    session.expires_at = now_ms() - 1

    touched = vault.touch_session()

    assert touched is False
    assert vault._session is None
    assert not any(key), "expired key must be zeroized"
    assert memory._closed, "expiry must invalidate open memory handles"


def test_idle_touch_is_capped_by_the_absolute_maximum(config, vault, monkeypatch):
    config.session_timeout = 60
    config.session_absolute_timeout = 120
    vault.lock()
    session = vault.start_session(vault.unlock("test-passphrase-42"))
    key = session.mk
    started = session.started_at
    assert session.expires_at == started + 60_000
    assert session.absolute_expires_at == started + 120_000

    now = [started + 50_000]
    monkeypatch.setattr("brain.memory.vault.now_ms", lambda: now[0])
    assert vault.touch_session()
    assert session.expires_at == started + 110_000

    now[0] = started + 100_000
    assert vault.touch_session()
    assert session.expires_at == session.absolute_expires_at

    now[0] = session.absolute_expires_at
    assert not vault.touch_session(), "activity cannot move the hard deadline"
    assert vault._session is None
    assert not any(key)


def test_reconfiguring_the_same_key_cannot_reset_absolute_lifetime(vault):
    session = vault.session
    key = session.mk
    started = session.started_at
    absolute_deadline = session.absolute_expires_at
    sid = session.session_id

    same_session = vault.start_session(key, mode="passphrase", degraded=True)

    assert same_session is session
    assert same_session.session_id == sid
    assert same_session.started_at == started
    assert same_session.absolute_expires_at == absolute_deadline
    assert same_session.degraded is True


def test_provisional_authentication_is_not_an_unlocked_session(vault, brain):
    vault.lock()
    provisional_key = vault.unlock("test-passphrase-42")
    vault.begin_provisional(provisional_key)

    assert vault.session is None
    assert vault.is_unlocked() is False
    result = brain.handle("do not serve during second-factor verification")
    assert result.ok is False

    vault.discard_provisional()


def test_provisional_authentication_zeroizes_at_its_short_deadline(vault, monkeypatch):
    vault.lock()
    provisional = vault.begin_provisional(vault.unlock("test-passphrase-42"))
    key = provisional.mk
    monkeypatch.setattr("brain.memory.vault.now_ms", lambda: provisional.expires_at)

    assert vault.session is None
    assert vault._session is None
    assert not any(key)


def test_brain_slash_commands_refresh_idle_expiry(config, vault, brain, monkeypatch):
    fake_now = now_ms() + 1_000
    session = vault.session
    session.expires_at = fake_now + 1_000
    monkeypatch.setattr("brain.memory.vault.now_ms", lambda: fake_now)

    result = brain.handle("/help")

    assert result.ok
    assert session.expires_at == fake_now + config.session_timeout * 1_000


def test_expiry_during_a_long_turn_does_not_revive_or_return_answer(config, vault, memory):
    class ExpiringProvider:
        name = "expiring-test"
        needs_network = False

        def available(self):
            return True

        def complete(self, system, messages, tools=None, tools_mode="auto"):
            vault._session.expires_at = now_ms() - 1
            return Completion(text="must not be returned after expiry")

    agent = Brain(config, vault, memory, provider=ExpiringProvider())
    turn = agent.handle("test expiry after provider finishes")

    assert not turn.ok
    assert "expired" in turn.error.lower()
    assert "must not be returned" not in turn.answer
    assert vault._session is None


def test_api_user_memory_activity_touches_but_dashboard_polling_does_not(
        config, vault, memory, monkeypatch):
    gateway = Gateway(config, vault, memory)
    fake_now = now_ms() + 1_000
    session = vault.session
    session.expires_at = fake_now + 1_000
    fake_mono = time.monotonic()
    monkeypatch.setattr("brain.memory.vault.now_ms", lambda: fake_now)
    monkeypatch.setattr("brain.api.gateway.now_ms", lambda: fake_now)
    monkeypatch.setattr("brain.memory.vault.time.monotonic", lambda: fake_mono)

    status, payload = gateway.route("GET", "/v1/status", {}, {})
    assert status == 200
    assert session.expires_at == fake_now + 1_000, "status polling is not user activity"
    assert payload["session"]["absolute_expires_at"] == session.absolute_expires_at
    assert payload["session"]["absolute_expires_in_s"] == int(
        session.absolute_expires_at_monotonic - fake_mono)

    status, _ = gateway.route("GET", "/v1/memory/search", {"q": "nothing"}, {})
    assert status == 200
    assert session.expires_at == fake_now + config.session_timeout * 1_000
