"""Projects: turn ideas into business models, and resume them later.

Everything is stored as encrypted records in the vault (kind ``project``) and
as sealed files. Nothing here needs a cloud model: summaries and next steps are
built deterministically, so Nila stays useful offline.
"""
