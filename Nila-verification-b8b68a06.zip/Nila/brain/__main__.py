"""``python -m brain ...`` entry point."""
from .cli.main import main

if __name__ == "__main__":
    raise SystemExit(main())
