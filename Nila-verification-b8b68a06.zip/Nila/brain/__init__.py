"""Nila - a local-first, end-to-end encrypted personal AI agent.

The engineering identifier stays ``brain``/``personal-brain`` (import paths,
``$BRAIN_HOME``, ``PBX1`` envelope magic, HKDF domain strings); only the persona
is named. See docs/adr/0007-agent-name-nila.md.
"""
__version__ = "0.1.0"
__all__ = ["__version__"]
