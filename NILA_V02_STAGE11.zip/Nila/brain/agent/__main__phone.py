"""``python -m brain.agent.phone`` - run the phone bridge on its own.

The owner asked for the phone to work in both directions. The loop needs the
vault unlocked, so it has to be started *after* a passphrase; this module is what
the Windows ``nila-phone.bat`` and the long-running ``brain telegram poll`` call,
and it is deliberately separate from ``brain serve`` so a phone bridge can run in
its own window while the dashboard runs in another.
"""
from __future__ import annotations

import argparse
import getpass
import os
import sys


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(prog="python -m brain.agent.phone",
                                     description="Answer Telegram messages from your phone.")
    parser.add_argument("--home", default=os.environ.get("BRAIN_HOME", ""))
    parser.add_argument("--passphrase-env", default="", metavar="VAR",
                        help="read the passphrase from this variable (never from argv)")
    parser.add_argument("--passphrase-stdin", action="store_true")
    parser.add_argument("--once", action="store_true", help="one round trip, then exit")
    parser.add_argument("--timeout", type=float, default=25.0,
                        help="long-poll seconds (default 25)")
    parser.add_argument("--max-rounds", type=int, default=0)
    args = parser.parse_args(argv)

    from pathlib import Path

    from ..config import Config
    from ..memory.store import MemoryStore
    from ..memory.vault import Vault
    from .agent import Brain
    from .phone import PhoneBridge
    from .telegram import Telegram, TelegramError

    home = Path(args.home).expanduser() if args.home else Config.default_home()
    config = Config.load(home)
    vault = Vault(config)
    if not vault.exists():
        print(f"no vault at {home} - run setup.bat (or `brain init`) first", file=sys.stderr)
        return 2
    passphrase = ""
    if args.passphrase_env:
        passphrase = os.environ.get(args.passphrase_env, "")
    elif args.passphrase_stdin:
        passphrase = sys.stdin.readline().rstrip("\n")
    if not passphrase:
        try:
            passphrase = getpass.getpass("master passphrase: ")
        except (EOFError, KeyboardInterrupt):
            return 2
    totp = ""
    try:
        vault.unlock(passphrase)
        mkey = vault.session.mk
        vault.start_session(mkey, mode="normal")
    except Exception as exc:
        print(f"could not unlock: {exc}", file=sys.stderr)
        return 2
    memory = MemoryStore(config, mkey, session=vault.session)
    bridge = Telegram(vault=vault)
    if not bridge.configured:
        print(Telegram(vault=vault).status()["how"], file=sys.stderr)
        memory.close(); vault.lock()
        return 2
    brain = Brain(config, vault, memory)
    loop = PhoneBridge(bridge, brain=brain, printer=lambda line: print(line, flush=True))
    print(f"Nila is listening on Telegram for chat {bridge.chat_id}."
          "\nClose this window to stop (the vault locks when it closes).", flush=True)
    try:
        result = loop.run(once=args.once, max_rounds=args.max_rounds,
                          timeout=args.timeout)
        if args.once:
            print(result)
        return 0 if result.get("ok", True) else 1
    except KeyboardInterrupt:
        print("\nstopped.")
        return 0
    except TelegramError as exc:
        print(f"phone bridge: {exc}", file=sys.stderr)
        return 1
    finally:
        memory.close()
        vault.lock()


if __name__ == "__main__":
    raise SystemExit(main())
